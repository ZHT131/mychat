<?php
/**
 * This file is part of workerman.
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the MIT-LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @author walkor<walkor@workerman.net>
 * @copyright walkor<walkor@workerman.net>
 * @link http://www.workerman.net/
 * @license http://www.opensource.org/licenses/mit-license.php MIT License
 */

/**
 * 用于检测业务代码死循环或者长时间阻塞等问题
 * 如果发现业务卡死，可以将下面declare打开（去掉//注释），并执行php start.php reload
 * 然后观察一段时间workerman.log看是否有process_timeout异常
 */

//declare(ticks=1);

use \GatewayWorker\Lib\Gateway;
use addons\moyicosmic\library\Moyigateway;

/**
 * 主逻辑
 * 主要是处理 onConnect onMessage onClose 三个方法
 * onConnect 和 onClose 如果不需要可以不用实现并删除
 */
class Events
{
    /**
     * 当客户端连接时触发
     * 如果业务不需此回调可以删除onConnect
     *
     * @param int $client_id 连接id
     */
    public static function onConnect($client_id)
    {
        echo '默认连接开始' . $client_id . "\r\n";
    }

    /**
     * 当客户端连接时触发Plus
     * @param $client_id
     * @param $data
     * @throws \think\Exception
     */
    public static function onWebSocketConnect($client_id, $data)
    {
        echo '连接Plus开始' . $client_id . "\r\n";
        if (Moyigateway::checkToken($data['get']['token'], $data['get']['id'])) {
            echo 'ok';
            // 绑定ID
            Gateway::bindUid($client_id, $data['get']['id']);
            Gateway::sendToUid($data['get']['id'], Moyigateway::success('Login successfully', [], 'init'));
            foreach (Moyigateway::notPushMsg($data['get']['id']) as $row) {
                echo '开始推送';
                Gateway::sendToClient($client_id,Moyigateway::success('',['form'=>$row['from'],'to'=>$row['to'],'type'=>'text','value'=>$row['value'],'time'=>$row['time']],'msg'));
            }
        } else {
            echo '登陆失败';
            Gateway::sendToClient($client_id,Moyigateway::error('登陆失败', [], 'init',401));
        }
    }

    /**
     * 当客户端发来消息时触发
     * @param $client_id
     * @param $message
     * @throws \think\Exception
     */
    public static function onMessage($client_id, $message)
    {
        echo "收到消息" . $message. "\r\n";
        @$data = json_decode($message);
        $uid = Gateway::getUidByClientId($client_id);
        print_r($data);
        echo "\r\n";
        echo "当前用户id".$uid."\r\n";

        if(!$uid){

            echo('获取uid错误,重试'.$client_id);
            $uid = Gateway::getUidByClientId($client_id);
            echo "重试后当前用户id".$uid."\r\n";

        }

        if ($data&&$uid) {
            switch ($data->type) {
                case 'ping':
                    echo '用户心跳正常UID:'.$uid."\r\n";
                    break;
                case 'text':
                    echo '发送给文本消息用户UID:'.$uid."\r\n";
                    // 检查好友关系
                    if (true||$data->to==$uid|| Moyigateway::checkFriend($data->to,$uid)){
                        // 检查是否在线
                        if ( Gateway::isUidOnline($data->to)){
                            // 发送消息给用户
                            echo '发送对象在线已发送';
                            Moyigateway::saveRecord($data,1);
                            Gateway::sendToUid($data->to,Moyigateway::success('',['id'=>$data->id + time(),'to'=>$data->to,'form'=>$data->from,'type'=>'text','value'=>$data->value],'msg'));
                        }else{
                            echo '发送对象未在线聊天记录以存档';
                            Moyigateway::saveRecord($data,0);
                        }
                        // 答复请求
                        Gateway::sendToUid($uid,Moyigateway::success('',['id'=>$data->id,'to'=>$uid,'form'=>$data->to,'value'=>null],'response'));
                    }else{
                        // 答复请求
                        Gateway::sendToUid($uid,Moyigateway::success('',['id'=>$data->id,'to'=>$uid,'form'=>$data->to,'value'=>'Fail'],'response'));
                        // 返回提示
                        Gateway::sendToUid($uid,Moyigateway::success('',['id'=>time(),'to'=>$uid,'form'=>$data->to,'type'=>'tips','value'=>'对方未添加你为好友'],'msg'));
                    }
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 当用户断开连接时触发
     * @param int $client_id 连接id
     */
    public static function onClose($client_id)
    {
//        $uid = Gateway::getUidByClientId($client_id);
//        echo "用户下线UID:      " . $uid . "\r\n";
    }
}
