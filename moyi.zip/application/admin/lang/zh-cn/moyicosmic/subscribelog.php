<?php

return [
    'Id'         => 'ID',
    'Type'       => '平台',
    'Params'     => '参数',
    'Msg'        => '消息',
    'Template'   => '模版ID',
    'Code'       => '代码',
    'Status'     => '状态',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间'
];
