<?php

return [
    'Id'                => 'ID',
    'Type'              => '平台',
    'Code'              => '调用代码',
    'Template'          => '模版ID',
    'Params'            => '参数',
    'Page'              => '默认卡片跳转链接',
    'Miniprogram_state' => '跳转类型',
    'Note'              => '备注',
    'Createtime'        => '创建时间',
    'Updatetime'        => '更新时间',
    'Deletetime'        => '删除时间',
    'Status'            => '状态',
    'Params key'        => '参数key',
    'Params value'      => '参数value'
];
