<?php
// +----------------------------------------------------------------------
// | FileName: Moyialiyun.php
// +----------------------------------------------------------------------
// | Date: 2019-12-10
// +----------------------------------------------------------------------
// | Source:  ( https://www.fastadmin.net/store/moyi.html )
// +----------------------------------------------------------------------
// | Author: 默毅 <moyi@mymoyi.cn>
// +----------------------------------------------------------------------

namespace addons\moyicosmic\library;

use addons\moyicosmic\library\Alipay\DefaultAcsClient;
use addons\moyicosmic\library\Alipay\Profile\DefaultProfile;
use addons\moyicosmic\library\Alipay\Request\ImageSyncScanRequest;
use addons\moyicosmic\library\Alipay\Request\TextScanRequest;


/**
 * Class Moyialiyun
 * @package addons\moyi\library
 * 阿里云SDK操作
 */
class AlipayHelper
{

    /**
     * @return DefaultProfile|Alipay\Profile\IClientProfile
     */
    public static function iClientProfile(){
        $conf = get_addon_config('moyicosmic');
        $profile =   DefaultProfile::getProfile(trim($conf['aliyun_audit_region']), trim($conf['aliyun_id']), trim($conf['aliyun_secret']));
        DefaultProfile::addEndpoint(trim($conf['aliyun_audit_region']), trim($conf['aliyun_audit_region']), "Green", trim($conf['aliyun_audit_domain']));
        return $profile;
    }
    /**
     * 检查单个文本
     * @param $content
     * @return object|array|boolean
     */
    public static function checkText($content)
    {
        $conf = get_addon_config('moyicosmic');

        $iClientProfile = self::iClientProfile();
        $client = new DefaultAcsClient($iClientProfile);
        $request = new TextScanRequest();
        $request->setMethod("POST");
        $request->setAcceptFormat("JSON");
        $task = [
            'dataId' => uniqid(),
            'content' => $content
        ];
        $request->setContent(json_encode([
            'bizType'=>$conf['aliyun_audit_biz'],
            "tasks" => [$task],
            "scenes" => ['antispam']
        ]));
        $response = $client->getAcsResponse($request);
        $result = [];
        if (!empty($response) && 200 == $response->code) {
            $taskResults = $response->data;
            foreach ($taskResults as $taskResult) {
                if (200 == $taskResult->code) {
                    $sceneResults = $taskResult->results;
                    foreach ($sceneResults as $sceneResult) {
                        @$suggestion = $sceneResult->suggestion;
                        $result = $taskResult;
                    }
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
        if (empty($result->results[0]->details)){
            return ($result->results[0]);
        }else{
            return empty($result->results[0]->details[0])?$result->results[0]->details:$result->results[0]->details[0];
        }
    }

    /**
     * 检查图片
     * @param $image array
     * @return object|array|boolean
     */
    public static function checkImage($image=[])
    {
        $conf = get_addon_config('moyicosmic');
        $scenes = [];
        foreach (explode(',', $conf['aliyun_audit_image_scenes']) as $item){
            $scenes[] = $item;
        }
        $iClientProfile = self::iClientProfile();
        $client = new DefaultAcsClient($iClientProfile);
        $request = new ImageSyncScanRequest();
        $request->setMethod("POST");
        $request->setAcceptFormat("JSON");
        $task = [];
        foreach ($image as $item){
            $task[] = [
                'url' => $item
            ];
        }
        $request->setContent(json_encode([
            'bizType'=>$conf['aliyun_audit_biz'],
            "tasks" =>$task,
            "scenes" => $scenes
        ]));

        $response = $client->getAcsResponse($request);
        $result = [];
        if (!empty($response) && 200 == $response->code) {
            $taskResults = $response->data;
            foreach ($taskResults as $index => $taskResult) {
                if (200 == $taskResult->code) {
                    $result[] = $taskResult->results;
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
        return $result;
    }

}
