<?php

namespace addons\moyicosmic\controller;

use app\common\controller\Api;

class Index extends Api
{
    public function index()
    {
        $this->error('测试');
    }
}
