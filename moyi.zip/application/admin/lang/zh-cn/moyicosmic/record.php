<?php

return [
    'Autoid'     => 'ID',
    'Id'         => '客户端返回的时间ID',
    'To'         => '发送至ID',
    'From'       => '来自ID',
    'Type'       => '类型',
    'Value'      => '值',
    'Status'     => '状态',
    'Status 0'   => '未推送',
    'Status 1'   => '已推送',
    'Time'       => '客户端发送时间戳',
    'Createtime' => '创建时间',
    'Deletetime' => '删除时间'
];
