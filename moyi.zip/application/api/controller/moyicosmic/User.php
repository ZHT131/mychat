<?php

namespace app\api\controller\moyicosmic;

use addons\moyicosmic\library\WechatHelper;
use app\admin\model\moyicosmic\Third;
use app\common\library\Sms;
use fast\Random;
use addons\moyicosmic\library\Common;
use think\Exception;

/**
 * BASE
 */
class User extends Base
{
    protected $noNeedLogin = [
        'login',
        'wechatLogin',
        'mobilelogin',
        'register',
        'resetpwd',
        'changeemail',
        'changemobile',
    ];
    protected $noNeedRight = '*';

    public function _initialize()
    {
        parent::_initialize();
    }

    /**
     * 手机验证码登录
     * @ApiMethod (POST)
     * @param string $mobile 手机号
     * @param string $captcha 验证码
     */
    public function mobileLogin()
    {
        $mobile = $this->request->post('mobile');
        $captcha = $this->request->post('captcha');
        $event = 'login';
        if (!$mobile || !$captcha || !is_numeric($mobile)) {
            $this->error(__('Invalid parameters'));
        }
        if (!Sms::check($mobile, $captcha, $event)) {
            $this->error(__('Captcha is incorrect'));
        }
        $user = \app\common\model\User::getByMobile($mobile);
        if ($user) {
            if ($user->status != 'normal') {
                $this->error(__('Account is locked'));
            }
            $ret = $this->auth->direct($user->id);
        } else {
            $ret = $this->auth->register($mobile, Random::alnum(), '', $mobile, []);
        }
        if ($ret) {
            Sms::flush($mobile, $event);

            $data = ['userinfo' =>array_merge(Common::getUserInfo(1,true),$this->auth->getUserinfo())];
            $this->success(__('Logged in successful'), $data);
        } else {
            $this->error($this->auth->getError());
        }
    }


    /**
     * 会员登录
     * @ApiMethod (POST)
     * @param string $account 账号
     * @param string $password 密码
     */
    public function login()
    {
        $account = $this->request->post('account');
        $password = $this->request->post('password');
        if (!$account || !$password) {
            $this->error(__('缺少参数'));
        }
        $ret = $this->auth->login($account, $password);
        if ($ret) {
            $data = ['userInfo' => array_merge(Common::getUserInfo($this->auth->getUserinfo()['id'],true),$this->auth->getUserinfo())];
            $this->success(__('登陆成功'), $data);
        } else {
            $this->error($this->auth->getError());
        }
    }
    /**
     * 编辑资料
     * @ApiMethod (POST)
     * @param string $account 账号
     * @param string $password 密码
     */
    public function editProfile()
    {
        $user = $this->auth->getUser();
        $nickname = $this->request->post('nickname');
        $bio = $this->request->post('bio');
        $avatar = $this->request->post('avatar', '', 'trim,strip_tags,htmlspecialchars');
        if (!Common::auditImages($avatar)||!Common::auditText($bio)||!Common::auditText($nickname)){
            $this->error('您更新资料内容涉嫌违规(色情、广告、灌水、渉政、辱骂等内容风险！)');
        }
        $user->nickname = $nickname;
        $user->bio = $bio;
        $user->avatar = $avatar;
        $user->save();
        $this->success('保存成功');
    }

    /**
     * 修改密码
     * @ApiMethod (POST)
     * @param string $pwd 旧密码
     * @param string $npwd 新密码
     * @param string $cpwd 重复密码
     */
    public function changePassword()
    {
        $oldPassword = $this->request->post("pwd");
        $newPassword = $this->request->post("npwd");
        $newPasswords = $this->request->post("cpwd");
        if ($newPassword != $newPasswords) {
            $this->error(__('验证错误'));
        }
        if (!$oldPassword) {
            $user = $this->auth->getUser();
            if ($user->password) {
                $this->error(__('密码错误'));
            }
            $ret = $this->auth->changepwd($newPassword, '', true);
        } else {
            $ret = $this->auth->changepwd($newPassword, $oldPassword);
        }
        if ($ret) {
            $this->success(__('密码重置成功'));
        } else {
            $this->error('密码错误');
        }
    }
    /**
     * 修改密码
     * @ApiMethod (POST)
     * @param string $pwd 旧密码
     * @param string $npwd 新密码
     * @param string $cpwd 重复密码
     */
    public function changeMobile()
    {
        $oldMobile = $this->request->post("oldMobile");
        $newMobile = $this->request->post("newMobile");
        $captcha = $this->request->post("captcha");
        $event = 'bindMobile';
        $user = $this->auth->getUser();

        $ret = Sms::check($newMobile, $captcha, $event);
        $ret = 1 ;
        if ($ret) {
            // 检查旧号码
            if ($user->mobile != $oldMobile) {
                $this->error(__('旧手机号码错误'));
            }
            //清除验证码
            Sms::flush($newMobile, $event);
            $user->mobile = $newMobile;
            $user->save();
            $this->success(__('绑定成功'));
        }else{
            $this->error('验证码错误');
        }
    }



    /**
     * 刷新用户
     * @ApiMethod (POST)
     */
    public function refreshUser()
    {
        if ($this->auth->isLogin()) {
            $data = ['userInfo' => array_merge(Common::getUserInfo(1,true),$this->auth->getUserinfo())];
            $this->success(__('Refresh successful'), $data);
        } else {
            $this->error(__('Refresh fail'));
        }
    }

    /**
     * @return mixed
     * @throws \think\exception\DbException
     */
    public function wechatLogin()
    {
        $code = $this->request->post('code');
        $encryptedData = $this->request->post('encryptedData');
        $iv = $this->request->post('iv');
        // 参数不完整返回
        if (!@$code||!@$encryptedData||!@$iv) {
            $this->error(__('缺少参数'));
        }
        // 引入封装的类
        $wechat = new WechatHelper();
        // 先验证code
        $result = $wechat->exchangeAuthorizationCode($code);
        if (!$result) {
            $this->error($wechat->getErrorMsg());
        }
        //查找当前微信是否有账号
        $third = Third::get([
            'type' => 'wechat',
            'openid' => $result['openid']
        ]);
        if ($third && $third['user_id']) {
            $this->auth->direct($third['user_id']);
            $data = ['userInfo' => array_merge(Common::getUserInfo($third['user_id'],true),$this->auth->getUserinfo())];
            $this->success(__('登陆成功'), $data);
        }

        // 调用库登陆微信
        $result = $wechat->decryptUserInfo($encryptedData,$iv,$result['session_key']);
        if (!$result) {
            $this->error($wechat->getErrorMsg());
        }
        $result['nickname'] = $result['nickName'];
        $result['gender'] = $result['gender']==1?1:0;

        // 新建用户
        $user_id=Common::createUser($result);
        if (!$user_id){
            $this->error('用户创建失败');
        }

        $this->auth->direct($user_id);
        $avatar =  Common::imageSave($result['avatarUrl'],$this->auth->getUserinfo()['token'],$this->request->domain());
        $result['avatar'] = $avatar!=false?$avatar:$result['avatarUrl'];
        $result['openid'] = $result['openId'];
        $result['type'] = 'wechat';
        $result['user_id'] = $user_id;

        //存第三方登陆数据库
        @$third = new Third($result);
        @$third->allowField(true)->save();
        $user = $this->auth->getUser();
        $user['avatar']=$result['avatar'];
        $user->save();

        $data = ['userInfo' => array_merge(Common::getUserInfo($third['user_id'],true),$this->auth->getUserinfo())];
        $this->success(__('登陆成功'), $data);
    }

    /**
     * 注销登录
     * @ApiMethod (POST)
     */
    public function logout()
    {
        if ($this->auth->isLogin()) {
            $this->auth->logout();
            $this->success(__('Logout successful'));
        } else {
            $this->error(__('Operation failed'));
        }
    }

}
