<?php

return [
    'Id'         => 'ID',
    'Text'       => '文字内容',
    'Type'       => '类型',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间',
    'Status'     => '状态'
];
