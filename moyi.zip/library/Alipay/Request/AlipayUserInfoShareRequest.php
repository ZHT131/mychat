<?php
/**
 * ALIPAY API: alipay.user.info.share request
 *
 * @author auto create
 *
 * @since  1.0, 2018-06-13 16:34:04
 */

namespace addons\moyicosmic\library\Alipay\Request;

class AlipayUserInfoShareRequest extends AbstractAlipayRequest
{

}
