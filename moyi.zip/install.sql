

-- 表的结构 `__PREFIX__moyi_third`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_third` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` varchar(25) NOT NULL DEFAULT '' COMMENT '第三方登录类型',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '会员ID',
  `openid` varchar(50) NOT NULL DEFAULT '' COMMENT '第三方唯一ID',
  `unionid` varchar(50) DEFAULT '' COMMENT '第三方唯一UNID',
  `access_token` varchar(255) NOT NULL DEFAULT '' COMMENT 'AccessToken',
  `session_key` varchar(50) DEFAULT NULL COMMENT 'Session_key',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `gender` smallint(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT '性别 0：未知、1：男、2：女',
  `language` varchar(50) DEFAULT NULL COMMENT '语言',
  `city` varchar(80) DEFAULT NULL COMMENT '城市',
  `province` varchar(80) DEFAULT NULL COMMENT '省',
  `country` varchar(80) DEFAULT NULL COMMENT '国家',
  `country_code` varchar(20) DEFAULT NULL COMMENT '手机号码国家编码',
  `mobile` varchar(20) DEFAULT NULL COMMENT '手机号码',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  `deletetime` int(10) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='第三方登录表';
COMMIT;

--

--
-- 表的结构 `__PREFIX__mychat_cosmos`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_feedback` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '1' COMMENT '用户ID',
  `text` varchar(1500) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '文字内容',
  `images` varchar(1500) NOT NULL DEFAULT '' COMMENT '相册组',
  `contact` varchar(50) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '联系方式',
  `createtime` int(10) UNSIGNED DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) UNSIGNED DEFAULT NULL COMMENT '更新时间',
  `deletetime` int(10) UNSIGNED DEFAULT NULL COMMENT '删除时间',
  `status` enum('normal','hidden') NOT NULL DEFAULT 'normal' COMMENT '状态',
  PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='反馈意见';

--
-- 新建表 `__PREFIX__moyi_custom`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_cms` (
  `id` smallint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '标题',
  `content` mediumtext COMMENT '内容',
  `views` int(10) DEFAULT NULL COMMENT '点击量',
  `createtime` int(10) DEFAULT NULL COMMENT '添加时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COMMENT='单页';
BEGIN;

--
-- 转存表中的数据 `__PREFIX__moyi_custom`
--

INSERT INTO `__PREFIX__moyicosmic_cms` (`id`, `title`, `content`, `createtime`, `updatetime`, `views`) VALUES
(1, '用户协议', '<p style=\"margin-bottom: 20px;\">　　1．特别提示</p><p style=\"margin-bottom: 20px;\">　　1．1　_________媒体（以下简称_________）同意按照本协议的规定及其不时发布的操作规则提供基于互联网的相关服务（以下称网络服务），为获得网络服务，服务使用人（以下称用户）应当同意本协议的全部条款并按照页面上的提示完成全部的注册程序。用户在进行注册程序过程中点击同意按钮即表示用户完全接受本协议项下的全部条款。</p><p style=\"margin-bottom: 20px;\">　　2．服务内容</p><p style=\"margin-bottom: 20px;\">　　2．1　_________网络服务的具体内容由_________根据实际情况提供，例如论坛（bbs）、聊天室、电子邮件、发表新闻评论等。_________保留随时变更、中断或终止部分或全部网络服务的权利。</p><p style=\"margin-bottom: 20px;\">　　2．2　_________在提供网络服务时，可能会对部分网络服务（例如电子邮件）的用户收取一定的费用。在此情况下，_________会在相关页面上做明确的提示。如用户拒绝支付该等费用，则不能使用相关的网络服务。</p><p style=\"margin-bottom: 20px;\">　　2．3　用户理解，_________仅提供相关的网络服务，除此之外与相关网络服务有关的设备（如电脑、调制解调器及其他与接入互联网有关的装置）及所需的费用（如为接入互联网而支付的电话费及上网费）均应由用户自行负担。</p><p style=\"margin-bottom: 20px;\">　　3．使用规则</p><p style=\"margin-bottom: 20px;\">　　3．1　用户在申请使用_________网络服务时，必须向_________提供准确的个人资料，如个人资料有任何变动，必须及时更新。</p><p style=\"margin-bottom: 20px;\">　　3．2　用户注册成功后，_________将给予每个用户一个用户帐号及相应的密码，该用户帐号和密码由用户负责保管；用户应当对以其用户帐号进行的所有活动和事件负法律责任。</p><p style=\"margin-bottom: 20px;\">　　3．3　用户必须同意接受_________通过电子邮件或其他方式向用户发送的商品促销或其他相关商业信息。</p><p style=\"margin-bottom: 20px;\">　　3．4　用户在使用_________网络服务过程中，必须遵循以下原则：</p><p style=\"margin-bottom: 20px;\">　　（1）遵守中国有关的法律和法规；</p><p style=\"margin-bottom: 20px;\">　　（2）不得为任何非法目的而使用网络服务系统；</p><p style=\"margin-bottom: 20px;\">　　（3）遵守所有与网络服务有关的网络协议、规定和程序；</p><p style=\"margin-bottom: 20px;\">　　（4）不得利用_________网络服务系统进行任何可能对互联网的正常运转造成不利影响的行为；</p><p style=\"margin-bottom: 20px;\">　　（5）不得利用_________网络服务系统传输任何骚扰性的、中伤他人的、辱骂性的、恐吓性的、庸俗淫秽的或其他任何非法的信息资料；</p><p style=\"margin-bottom: 20px;\">　　（6）不得利用_________网络服务系统进行任何不利于_________的行为；</p><p style=\"margin-bottom: 20px;\">　　（7）如发现任何非法使用用户帐号或帐号出现安全漏洞的情况，应立即通告_________。</p><p style=\"margin-bottom: 20px;\">　　4．内容所有权</p><p style=\"margin-bottom: 20px;\">　　4．1　_________提供的网络服务内容可能包括：文字、软件、声音、图片、录像、图表等。所有这些内容受版权、商标和其它财产所有权法律的保护。</p><p style=\"margin-bottom: 20px;\">　　4．2　用户只有在获得_________或其他相关权利人的授权之后才能使用这些内容，而不能擅自复制、再造这些内容、或创造与内容有关的派生产品。</p><p style=\"margin-bottom: 20px;\">　　5．隐私保护</p><p style=\"margin-bottom: 20px;\">　　5．1　保护用户隐私是_________的一项基本政策，_________保证不对外公开或向第三方提供用户注册资料及用户在使用网络服务时存储在_________的非公开内容，但下列情况除外：</p><p style=\"margin-bottom: 20px;\">　　（1）事先获得用户的明确授权；</p><p style=\"margin-bottom: 20px;\">　　（2）根据有关的法律法规要求；</p><p style=\"margin-bottom: 20px;\">　　（3）按照相关政府主管部门的要求；</p><p style=\"margin-bottom: 20px;\">　　（4）为维护社会公众的利益；</p><p style=\"margin-bottom: 20px;\">　　（5）为维护_________的合法权益。</p>', 1564393697, 1564410444, 20),
(2, '联系我们', '<p style=\"text-align: center; line-height: 3;\"><span style=\"font-size: 18px;\"><b>姓名：刘毅</b></span></p><p style=\"text-align: center; line-height: 3;\"><span style=\"font-size: 18px;\"><b>联系电话：17080057443</b></span></p><p style=\"text-align: center; line-height: 3;\"><span style=\"font-size: 18px;\"><b>WeChat：fyxgzs</b></span></p><p style=\"text-align: center; \"><span style=\"font-size: 18px;\"><b><br></b></span></p><p style=\"text-align: center; \"><span style=\"font-size: 18px;\"><b>地址：巴拉巴拉魔仙堡</b></span></p><p style=\"text-align: center; \"><span style=\"font-size: 18px;\"><b><br></b></span></p><p style=\"text-align: center; \"><b><img src=\"http://cdn.fyxbl.top/uploads/20190729/FqHFBGEbM16qMzoAJncgv_NGZxxp.png\" style=\"width: 100%;\" data-filename=\"filename\"></b><br></p>', 1564394368, 1564410441, 9),
(3, '关于我们', '<p style=\"text-align: left;\"><br></p><table class=\"table table-bordered\"><tbody><tr><td><p><span style=\"background-color: transparent;\">欢迎使用默毅系列产品。以下条款和条件构成您与深圳默毅品牌广告策划有限公司(以下简称“默毅品牌设计”)就软件使用许可所达成的协议。</span><br></p><p>用户安装和使用此产品，即意味着同意以下条款和条件。</p><p><br></p><p>1&nbsp; &nbsp;知识产权声明</p><p><br></p><p>&nbsp;受国家计算机软件著作权保护，不得恶意分享产品源代码、二次转售等，违者必究。</p><p><br></p><p>2&nbsp; &nbsp;用户使用许可授权范围</p><p>2.1、保留权利： 本《协议》未明示授权的其他一切权利仍归默毅品牌设计所有，用户使用其他权利时须另外取得默毅品牌设计的书面同意。</p><p>2.2、除本《协议》有明确规定外，本《协议》并未对利用本\"软件\"访问的默毅品牌设计的其他相关单独服务的服务条款予以列明，对于这些服务可能有单独的服务条款加以规范，请用户在使用有关服务时另行了解与确认。如用户使用该服务，视为对相关服务条款的接受。</p><p><br></p><p>3&nbsp; &nbsp;权利与义务</p><p><br></p><p>3.1、未获商业授权之前，不得将本软件用于商业用途（包括但不限于企业网站、经营性网站、以营利为目或实现盈利及具有同等或类似功能的网站）。</p><p>3.2、不得对所获本软件授权进行重新分发、出租、出售、抵押或发放子许可证，不得通过拷贝、复制、泄露、授权等方式给任意第三方包括用户的关联公司。也不得以任何方式将系统源代码及系统本身提供给任意第三方包括用户的关联公司，否则应承担相应赔偿责任。</p><p>3.3、默毅品牌设计将本软件提供给授权用户，同时提供软件的安装说明，使用说明等文档，授权网站、用户依法享有该软件的使用权。</p><p>3.4、授权用户拥有其系统内全部会员资料、商品资料、订单资料及相关信息的所有权，并独立承担相关法律义务。</p><p>3.5、利用本授权软件发生的商业行为均由授权用户自行负责，利用本软件进行商业行为所产生的一切纠纷均与默毅品牌设计无关。</p><p>3.6、为方便用户使用，软件内置了譬如网上支付网关、短信网关等诸多第三方系统。但您应自行评估使用这些系统的风险。这些系统的具体开通与服务由相应第三方公司提供，由此而产生的任何商业纠纷，均与默毅品牌设计无关。</p><p>3.7、授权软件升级前授权用户应自行备份数据，升级过程中造成的授权用户数据丢失的默毅品牌设计不承担责任。</p><p>3.8、默毅品牌设计不对因授权软件使用错误、软件错误等问题所引起的授权用户损失而承担任何责任，但默毅品牌设计将尽量避免此类情况的发生。</p><p>3.9、您不得在非授权的情况下，私自去除默毅品牌设计软件前台、后台版权，如有以上行为发生，将视为您侵犯了默毅品牌设计的知识产权，默毅品牌设计将保留起诉、追究法律责任并要求获得赔偿的权利。</p><p>3.10、授权用户将在享有上述条款授予的权力的同时，受到相关的约束和限制。协议许可范围以外的行为，将直接违反本授权协议并构成侵权，我们有权随时终止授权，责令停止损害，并保留追究相关责任的权力。</p><p>3.11、因本协议履行过程中的争议，由默毅品牌设计所在地人民法院审理。</p></td></tr></tbody></table><p style=\"text-align: left;\"><br></p>', 1564396495, 1564410581, 6);
COMMIT;



--
-- 表的结构 `__PREFIX__mychat_friend`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_friend` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '当前用户',
  `friend_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '好友ID',
  `note_name` varchar(50) NOT NULL DEFAULT '' COMMENT '备注昵称',
  `state` enum('blacklist','normal','unverified','refuse') NOT NULL DEFAULT 'unverified' COMMENT '状态',
  `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  `deletetime` int(10) unsigned DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='好友列表';

--
-- 表的结构 `__PREFIX__mychat_record`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_record` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `to` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发送至ID',
  `from` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '来自ID',
  `type` varchar(50) NOT NULL DEFAULT 'text' COMMENT '类型',
  `value` varchar(5000) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '值',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态:0=未推送,1=已推送',
  `time` int(10) unsigned DEFAULT NULL COMMENT '客户端发送时间戳',
  `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  `deletetime` int(10) unsigned DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='聊天记录';


--
-- 表的结构 `__PREFIX__mychat_append`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_append` (

  `user_id` int(15) UNSIGNED NOT NULL DEFAULT '0' COMMENT '用户ID',
  `images` varchar(1500) NOT NULL DEFAULT '' COMMENT '相册组',
  `text` varchar(240) NOT NULL DEFAULT 'text' COMMENT '类型',
  `vip` int(2) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'vip登记',
  `bill` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '消费金额',
  `invite` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '邀请人数',
  `energy` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '能量',
  `frame` varchar(150) NOT NULL DEFAULT '' COMMENT '头像框',
  `frames` varchar(1500) NOT NULL DEFAULT '' COMMENT '头像框合集',
  `views` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '浏览',
  `likes` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '喜欢',
  `reviews` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '评论',
  `country` varchar(50) NOT NULL DEFAULT '半人马座' COMMENT '国家/地区',
  `place` varchar(50) NOT NULL DEFAULT '阿尔法星系' COMMENT '地区',
  `part` varchar(50) NOT NULL DEFAULT '三体星球' COMMENT '地点',
  `createtime` int(10) UNSIGNED DEFAULT NULL COMMENT '创建时间',
  `deletetime` int(10) UNSIGNED DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资料追加表';


--
-- 表的结构 `__PREFIX__mychat_cosmos`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_cosmos` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '1' COMMENT '用户ID',


  `age` int(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT '年龄',
  `gender` int(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT '性别',
  `zodiac` int(2) UNSIGNED NOT NULL DEFAULT '0' COMMENT '星座',
  `flag` varchar(150) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '标志组',


  `secret` varchar(50) NOT NULL DEFAULT '' COMMENT '隐私',
  `place` varchar(50) CHARACTER SET utf8mb4 NOT NULL DEFAULT '麦哲伦星云' COMMENT '地点',
  `views` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '浏览',
  `likes` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '喜欢',
  `reviews` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '评论',
  `shares` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '分享',
  `text` varchar(500) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '文字内容',
  `images` varchar(1500) NOT NULL DEFAULT '' COMMENT '相册组',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  `collect` smallint(1) NOT NULL DEFAULT '0' COMMENT '采集，0：正常、1：采集1号平台',
  `third_id` int(10) NOT NULL DEFAULT '0' COMMENT '防止重复采集第三方ID',
  `createtime` int(10) UNSIGNED DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) UNSIGNED DEFAULT NULL COMMENT '更新时间',
  `deletetime` int(10) UNSIGNED DEFAULT NULL COMMENT '删除时间',
  `status` enum('normal','hidden') NOT NULL DEFAULT 'normal' COMMENT '状态',

  PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='宇宙';


--
-- 表的结构 `__PREFIX__mychat_review`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_review` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) UNSIGNED NOT NULL DEFAULT '1' COMMENT '父ID',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '1' COMMENT '用户ID',
  `reply_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '回复ID',
  `reply_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '回复用户ID',
  `text` varchar(500) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '文字内容',
  `createtime` int(10) UNSIGNED DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) UNSIGNED DEFAULT NULL COMMENT '更新时间',
  `deletetime` int(10) UNSIGNED DEFAULT NULL COMMENT '删除时间',
  `status` enum('normal','hidden') NOT NULL DEFAULT 'normal' COMMENT '状态',
  PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='宇宙回响';


--
-- 表的结构 `__PREFIX__mychat_like`
--


CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_like` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) UNSIGNED NOT NULL DEFAULT '1' COMMENT '父ID',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '1' COMMENT '用户ID',
  `createtime` int(10) UNSIGNED DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) UNSIGNED DEFAULT NULL COMMENT '更新时间',
  `deletetime` int(10) UNSIGNED DEFAULT NULL COMMENT '删除时间',
  `status` enum('normal','hidden') NOT NULL DEFAULT 'normal' COMMENT '状态',
  PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='宇宙标记';




--
-- 表的结构 `__PREFIX__mychat_follow`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_follow` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '1' COMMENT '用户ID',
  `createtime` int(10) UNSIGNED DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) UNSIGNED DEFAULT NULL COMMENT '更新时间',
  `deletetime` int(10) UNSIGNED DEFAULT NULL COMMENT '删除时间',
  `status` enum('normal','hidden') NOT NULL DEFAULT 'normal' COMMENT '状态',
  PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='宇宙凝视';



--
-- 表的结构 `__PREFIX__mychat_follow`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_grace` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `text` varchar(500) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '文字内容',
  `type` varchar(50) NOT NULL DEFAULT 'text' COMMENT '类型',
  `createtime` int(10) UNSIGNED DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) UNSIGNED DEFAULT NULL COMMENT '更新时间',
  `deletetime` int(10) UNSIGNED DEFAULT NULL COMMENT '删除时间',
  `status` enum('normal','hidden') NOT NULL DEFAULT 'normal' COMMENT '状态',
  PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='优雅句子';



CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_token` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` varchar(50) NOT NULL DEFAULT '' COMMENT '类型',
  `token` varchar(256) NOT NULL DEFAULT '' COMMENT 'Token',
  `expires_in` int(10) UNSIGNED DEFAULT NULL COMMENT '有效时间',
  `expirestime` int(10) UNSIGNED DEFAULT NULL COMMENT '过期时间',
  `createtime` int(10) UNSIGNED DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) UNSIGNED DEFAULT NULL COMMENT '更新时间',
  `deletetime` int(10) UNSIGNED DEFAULT NULL COMMENT '删除时间',
  `status` enum('normal','hidden') NOT NULL DEFAULT 'normal' COMMENT '状态',
  PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='后台交换密钥';



CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_subscribe` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` enum('wechat','alipay') NOT NULL DEFAULT 'wechat' COMMENT '平台',
  `code` varchar(50) NOT NULL DEFAULT '' COMMENT '平台',
  `template` varchar(256) NOT NULL DEFAULT '' COMMENT '模版ID',
  `params` varchar(500) DEFAULT NULL COMMENT '参数',
  `page` varchar(256) NOT NULL DEFAULT '' COMMENT '默认卡片跳转链接',
  `miniprogram_state` varchar(32) NOT NULL DEFAULT '' COMMENT '跳转类型', -- 跳转小程序类型 developer为开发版；trial为体验版；formal为正式版
  `note` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `createtime` int(10) UNSIGNED DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) UNSIGNED DEFAULT NULL COMMENT '更新时间',
  `deletetime` int(10) UNSIGNED DEFAULT NULL COMMENT '删除时间',
  `status` enum('normal','hidden') NOT NULL DEFAULT 'normal' COMMENT '状态',
  PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='订阅消息模版';





CREATE TABLE IF NOT EXISTS `__PREFIX__moyicosmic_subscribe_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` enum('wechat','alipay') NOT NULL DEFAULT 'wechat' COMMENT '平台',
  `params` varchar(2048) DEFAULT NULL COMMENT '参数',
  `msg` varchar(100) DEFAULT NULL COMMENT '消息',
  `template` varchar(256) NOT NULL DEFAULT '' COMMENT '模版ID',
  `code` varchar(24) NOT NULL DEFAULT '' COMMENT '代码',
  `status` enum('success','error') NOT NULL DEFAULT 'success' COMMENT '状态',
  `createtime` int(10) UNSIGNED DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) UNSIGNED DEFAULT NULL COMMENT '更新时间',
  `deletetime` int(10) UNSIGNED DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='订阅消息发送记录';



--ACCESS_TOKEN
-- Review
--   `text` varchar(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '评论内容',

-- 升级用户名跟格言编码
-- ALTER TABLE `__PREFIX__user` CHANGE `nickname` `nickname` VARCHAR(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '昵称';
-- ALTER TABLE `__PREFIX__user` CHANGE `bio` `bio` VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '格言';