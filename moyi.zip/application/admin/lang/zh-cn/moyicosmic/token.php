<?php

return [
    'Id'         => 'ID',
    'Type'       => '类型',
    'Token'      => 'Token',
    'Expires_in' => '过期时间',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间',
    'Status'     => '状态'
];
