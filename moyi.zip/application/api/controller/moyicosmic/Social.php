<?php

namespace app\api\controller\moyicosmic;

use addons\moyicosmic\library\Common;
use fast\Random;
use app\admin\model\moyicosmic\Friend;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\exception\DbException;

/**
 * BASE
 */
class Social extends Base
{
    protected $noNeedLogin = [
        'friendsAdd'
    ];
    protected $noNeedRight = '*';

    public function _initialize()
    {
        parent::_initialize();
    }

    /**
     * 好友添加
     * @ApiMethod (POST)
     * @throws \think\exception\DbException
     */
    public function getUserInfo()
    {

        $user_id = $this->request->post('id');
        $info = \app\common\model\User::get($user_id);
        if ($info){
            $info->visible(['id','username','nickname','avatar','gender','bio']);
            $this->success('',$info);
        }else{
            $this->error('未找到该用户');
        }
    }
    /**
     * 好友添加
     * @ApiMethod (POST)
     * @throws \think\exception\DbException
     */
    public function friendsAdd()
    {
        $user_id = 1;
        $friend =9;
        $temp = Friend::get(['user_id'=>$user_id,'friend_id'=>$friend]);
        if ($temp){
            $this->error('以添加');
        }
        Friend::create(['user_id'=>$user_id,'friend_id'=>$friend]);
        $this->success('success');
    }

    /**
     * 好友列表
     * @ApiMethod (POST)
     */
    public function friendsList()
    {
        $user_id = $this->auth->getUserinfo()['id'];
        $friend = new Friend();
        try {
            $list = $friend->with(['user'])->where(['user_id' => $user_id])->select();

        } catch (DbException $e) {
            $this->error('error');
        }
        foreach ($list as $row) {
            // 隐藏不必要的传参
            $row->hidden(['id','user_id','friend_id','createtime','deletetime']);
            $row->getRelation('user')->visible(['id','username','nickname','avatar','gender','bio']);
            $row['sort'] = Common::getFirstChar($row->note_name ? $row->note_name:$row->user->nickname);
        }
        $list = collection((array)$list)->toArray();
        $this->success('',$list);
    }


    /**
     * 会员登录
     * @ApiMethod (POST)
     * @param string $account 账号
     * @param string $password 密码
     * @throws DbException
     */
    public function test()
    {
        if (Friend::get(['user_id'=>1,'friend_id'=>1081,'state'=>'normal'])){
            $this->success('4');
        }
        $this->success('2',Friend::get(['user_id'=>1,'friend_id'=>1082,'state'=>'normal']));

    }


}
