<?php

return [
    'Id'         => 'ID',
    'User_id'    => '用户ID',
    'Flag'       => '标志组',
    'Secret'     => '隐私',
    'Place'      => '地点',
    'Views'      => '浏览',
    'Likes'      => '喜欢',
    'Reviews'    => '评论',
    'Shares'     => '分享',
    'Text'       => '文字内容',
    'Images'     => '相册组',
    'Weigh'      => '权重',
    'Collect'    => '采集,0：正常、1：采集1号平台',
    'Createtime' => '创建时间',
    'Updatetime' => '删除时间',
    'Deletetime' => '删除时间',
    'Status'     => '状态'
];
