<?php
// +----------------------------------------------------------------------
// | FileName: Moyiwechat.php
// +----------------------------------------------------------------------
// | Date: 2019-08-05
// +----------------------------------------------------------------------
// | Source:  ( https://www.fastadmin.net/store/moyi.html )
// +----------------------------------------------------------------------
// | Author: 默毅 <moyi@mymoyi.cn>
// +----------------------------------------------------------------------

/**
 * 微信通讯类
 */

namespace addons\moyicosmic\library;

use app\admin\model\moyicosmic\Subscribe;
use app\admin\model\moyicosmic\Token;
use fast\Http;
use think\Config;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\Exception;
use think\exception\DbException;
use think\exception\HttpException;

class WechatHelper
{


    protected $appId = '';
    protected $secret = '';
    protected $errorMsg = '';
    protected $errorCode = 0;
    /**
     * @var string
     */
    public function __construct()
    {
        // 初始化基本参数
        $conf = get_addon_config('moyicosmic');
        $this->appId = $conf['wechat_id'];
        $this->secret = $conf['wechat_secret'];
    }

    /**
     * @param $touser string 接收者（用户）的 openid
     * @param $template_id string 所需下发的订阅模板id
     * @param $page string 点击模板卡片后的跳转页面，仅限本小程序内的页面。支持带参数,（示例index?foo=bar）。该字段不填则模板无跳转。
     * @param $data object|array 模板内容，格式形如 { "key1": { "value": any }, "key2": { "value": any } }
     * @param $retry bool    进入小程序查看”的语言类型，支持zh_CN(简体中文)、en_US(英文)、zh_HK(繁体中文)、zh_TW(繁体中文)，默认为zh_CN
     * @param $miniprogram_state string 跳转小程序类型：developer为开发版；trial为体验版；formal为正式版；默认为正式版
     * @return bool|mixed|string string    进入小程序查看”的语言类型，支持zh_CN(简体中文)、en_US(英文)、zh_HK(繁体中文)、zh_TW(繁体中文)，默认为zh_CN
     */

    public function subscribeMessageSend($params=array(),$retry = false) {
            $token = $this->getAccessToken();
            if (!$token) {
                $this->errorMsg = 'Token获取出错';
                return false;
            }
            $re = Http::post('https://api.weixin.qq.com/cgi-bin/message/subscribe/send?access_token=' . $token,
                json_encode($params));
            $re = json_decode($re, true);
            if (isset($re['errcode'])&&$re['errcode']!=0) {
                $this->errorMsg($re['errcode']);
                return false;
            } elseif (empty($re)) {
                if (!$retry) {
                    return $this->subscribeMessageSend($params, true);
                } else {
                    $this->errorMsg = '服务器链接';
                    return false;
                }
            } else {
                return true;
            }
    }

    /**
     * 获取小程序全局唯一后台接口调用凭据
     * @return array|boolean $appid, $secret,
     */
    public function getAccessToken()
    {
        $model = new Token();
        try {
            $token = $model
                ->where('type', 'wechat')
                ->order('id', 'desc')
                ->where('expirestime', '>', time() + 120)
                ->select();
            if ($token) {
                return $token[0]['token'];
            } else {
                $url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' . $this->appId . '&secret=' . $this->secret;
                $re = Http::get($url);
                $re = json_decode($re, true);
                if (isset($re['errcode'])) {
                    $this->errorMsg($re['errcode']);
                    return false;
                } else {
                    $model->data([
                        'type' => 'wechat',
                        'token' => $re['access_token'],
                        'expires_in' => $re['expires_in'],
                        'expirestime' => $re = time() + $re['expires_in']
                    ]);
                    $model->save();
                    return $model['token'];
                }
            }
        } catch (DataNotFoundException $e) {
        } catch (ModelNotFoundException $e) {
        } catch (DbException $e) {
            return false;
        }
        return false;
    }

    /**
     * 交换授权特征码
     * @param $code
     * @return array|boolean $appid, $secret,
     */
    public function exchangeAuthorizationCode($code)
    {
        try {
            $url = 'https://api.weixin.qq.com/sns/jscode2session?appid=' . $this->appId . '&secret=' . $this->secret . '&js_code=' . $code . '&grant_type=authorization_code';
            $re = Http::get($url);
            $re = json_decode($re, true);
            if (isset($re['errcode'])) {
                $this->errorMsg($re['errcode']);
                return false;
            } else {
                return $re;
            }
        } catch (HttpException $exception) {
            return false;
        }
    }

    // 获取错误讯息
    public function getErrorMsg()
    {
        return $this->errorMsg;
    }

    // 获取错误讯息
    public function getErrorCode()
    {
        return $this->errorCode;
    }

    /**
     * 解密用户数据
     * @param $encryptedData
     * @param $iv
     * @param $sessionKey
     * @return array|boolean
     */
    public function decryptUserInfo($encryptedData, $iv, $sessionKey)
    {

        if (strlen($sessionKey) != 24) {
            $this->errorMsg = 'sessionKey不正确';
            return false;
        }
        $aesKey = base64_decode($sessionKey);

        if (strlen($iv) != 24) {
            $this->errorMsg = 'iv不正确';
            return false;
        }
        $aesIV = base64_decode($iv);
        $aesCipher = base64_decode($encryptedData);
        $re = openssl_decrypt($aesCipher, "AES-128-CBC", $aesKey, 1, $aesIV);
        $data = json_decode($re, true);
        if ($data) {
            return $data;
        } else {
            $this->errorMsg = '解密错误';
            return false;
        }
    }

    /**
     * 错误信息
     * @param $code integer 代码
     * @return boolean       信息
     */
    function errorMsg($code)
    {
        if (!Config::get('app_debug')) {
            return false;
        }
        $msg = '未知错误';
        switch ($code) {
            case -1:
                $msg = '系统繁忙，此时请开发者稍候再试';
                break;
            case 0:
                $msg = '请求成功';
                break;
            case 40001:
                $msg = 'AppSecret 错误或者 AppSecret 不属于这个小程序，请开发者确认 AppSecret 的正确性	';
                break;
            case 40002:
                $msg = '请确保 grant_type 字段值为 client_credential';
                break;
            case 40003:
                $msg = 'openid 错误';
                break;
            case 40163:
                $msg = 'code重复使用';
                break;
            case 45011:
                $msg = '频率限制，每个用户每分钟100次';
                break;
            case 40013:
                $msg = '不合法的 AppID，请开发者检查 AppID 的正确性，避免异常字符，注意大小写';
                break;
            case 40016:
                $msg = '代码已被使用';
                break;
            case 40029:
                $msg = 'code 无效';
                break;
            case 89002:
                $msg = '没有绑定开放平台帐号';
                break;
            case 89300:
                $msg = '订单无效';
                break;
            case 41001:
                $msg = 'access_token未命中';
                break;
            case 43101:
                $msg = '用户拒绝消息';
                break;
        }
        $this->errorMsg = $msg;
        $this->errorCode = $code;
        return true;
    }


}
