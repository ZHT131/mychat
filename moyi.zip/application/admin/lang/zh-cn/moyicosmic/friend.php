<?php

return [
    'Id'            => 'ID',
    'User_id'       => '当前用户',
    'Friend_id'     => '好友ID',
    'Note_name'     => '备注昵称',
    'Createtime'    => '创建时间',
    'Deletetime'    => '删除时间',
    'User.username' => '用户名',
    'User.nickname' => '昵称',
    'User.avatar'   => '头像',
    'User.gender'   => '性别',
    'User.bio'      => '格言'
];
