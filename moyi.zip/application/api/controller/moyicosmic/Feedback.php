<?php
// +----------------------------------------------------------------------
// | FileName: Cosmos.php
// +----------------------------------------------------------------------
// | Date: 2020-03-16 
// +----------------------------------------------------------------------
// | Source:  ( https://www.fastadmin.net/store/moyi.html )
// +----------------------------------------------------------------------
// | Author: 默毅 <moyi@mymoyi.cn>
// +----------------------------------------------------------------------


namespace app\api\controller\moyicosmic;

use think\Exception;
use app\admin\model\moyicosmic\Feedback as FeedbackModel;

class Feedback extends Base
{

    /**
     * 标记
     * @ApiMethod (POST)
     *
     * @param string $pid pid
     * @throws Exception
     */
    public function push()
    {
        $text = $this->request->post('text');
        $contact = $this->request->post('contact');
        $images = $this->request->post('images');
        $user_id = $this->auth->getUserinfo()['id'];
        $arr = [
            'text' => $text,
            'contact' => $contact,
            'images' => $images,
            'user_id' => $user_id,
            'status' => 'normal'
        ];
        if (FeedbackModel::create($arr)) {
            $this->success('我们已收到您的反馈，将尽快处理。');
        } else {
            $this->error('您的反馈意见未送达');
        }
    }
}