<?php

namespace app\api\controller\moyicosmic;

use addons\moyicosmic\library\AlipayHelper;
use addons\moyicosmic\library\Common;
use addons\moyicosmic\moyicosmic;
use app\admin\model\moyicosmic\Append;
use app\admin\model\moyicosmic\Cosmos;
use addons\alioss\controller\index as alioss;
use app\admin\model\moyicosmic\Grace;
use app\api\controller\Common as apiCommon;

use fast\Http;
use fast\Random;
use think\Db;
use think\File;
use think\Hook;
use think\Config;


//use app\admin\command\Api;

set_time_limit(0);
ob_end_clean();
ob_implicit_flush();
header('X-Accel-Buffering: no');

/**
 * BASE
 */
class Test extends Base
{


//开发者账号：moyi@mymoyi.cn ， 开发者key：c1b19491c9f5ce3f38965573ce0cbca9 （用于获取【群成员】数据，详见【免费接口文档】）

    protected $noNeedLogin = ['collect','mosheng','test1'];

    function moshengs (){
        $this->mosheng;
        sleep(10);
        $this->mosheng;
        sleep(10);
        $this->mosheng;
        sleep(10);
        $this->mosheng;
        sleep(10);
        $this->mosheng;
        sleep(10);

    }
    public function http_request($url, $data = null, $header = null){
        $curl = curl_init();
        if(!empty($header)){
            curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
            curl_setopt($curl, CURLOPT_HEADER, 0);//返回response头部信息
        }

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        if (!empty($data)) {
            curl_setopt($curl, CURLOPT_HTTPGET, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS,http_build_query($data));
        }

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }
    function convertUrlQuery($query)
    {
        $queryParts = explode('&', $query);
        $params = array();
        foreach ($queryParts as $param) {
            $item = explode('=', $param);
            $params[$item[0]] = $item[1];
        }
        return $params;
    }
    //
    function mosheng (){

        $url = 'http://blognew.806409.com/blog_list.php?';
        $data = [
            'userid'=>'16990061928974',
            'offset'=>'0',
            'type'=>'all',
            'gender'=>'0',
            'limit'=>'100',
            'timestamp'=>''
        ];

        $options=array(
            'X-API-UA:mosheng.weiling (Android; OS/28; zh-cn; Branchs HUAWEI:HLKAL10) Version/4.6.8 Device/1080x2340 Ca/90017',
            'X-API-USERID:16990061928974',
            'X-API-TOKEN:1d58e74e56d35886b1ee092843fb653f',

//             X-API-USERID	16990061928974
// X-API-TOKEN	221b9a9a3063d16a115416bef41de801
        );

        $test = $this->http_request($url,$data,$options);
        $data = json_decode($test);
        // print_r($data);
        $i = 0;
        $collect_i = 0;
        if($data->errno != 0){
            if (get_addon_config('vbot')) {
                $vbot = new \addons\vbot\Vbot();
                $vbot->vbotSendMsg('collect_error', [], ['content'=>$data->content,'time'=>date("Y-m-d H:i:s",intval(time()))]);
            }
            return 'error';
        };
        foreach (array_reverse($data->data) as $res) {
            $images = '';
            $i ++;
            if ($res->type !=2){

                if (!Cosmos::get(['third_id' => $res->id, 'collect' => 2])) {
                    foreach (array_reverse($res->pictures) as $ress) {
                        if (!empty($ress->large)) {
                            $arr = parse_url($ress->large);
                            $arr_query = $this->convertUrlQuery($arr['query']);
                            $pic = urldecode($arr_query['pic']);
                            if (empty($images)) {
                                $images = $pic;
                            } else {
                                $images = $images . ',' . $pic;
                            }
                        }
                    }
                    $user_id = Common::createUser([
                        'username' => 'ms_' . $res->userid,
                        'nickname' => $res->nickname,
                        'avatar' => $res->avatar,
                        'gender' => $res->gender != 1 ? 0 : 1
                    ]);
                    Cosmos::create([
                        'user_id' => $user_id,
                        'text' => $res->description,
                        'third_id' => $res->id,
                        'collect' => 2,
                        'place' => $res->city,
                        'images' => $images,
                        'createtime' => $res->operat_time
                    ]);
                    $collect_i ++;
                }
            }
        }
        $res = [
            'platform'=>'陌声',
            'count'=>$i,
            'collect'=>$collect_i,
            'time'=>date("Y-m-d H:i:s",intval(time()))];
        if($i){
            if (get_addon_config('vbot')) {
                $vbot = new \addons\vbot\Vbot();
                $vbot->vbotSendMsg('collect_notice', [], $res);
            }
        }else{
            if (get_addon_config('vbot')) {
                $vbot = new \addons\vbot\Vbot();
                $vbot->vbotSendMsg('collect_error', [], ['content'=>$data]);
            }
        }

    }
    function filterEmoji($str)
    {
        $str = preg_replace_callback(
            '/./u',
            function (array $match) {
                return strlen($match[0]) >= 4 ? $this->emmoji() : $match[0];
            },
            $str);

        return $str;
    }

    function emmoji(){
        $arr = ["[微笑]",
            "[撇嘴]",
            "[色]",
            "[发呆]",
            "[得意]",
            "[流泪]",
            "[害羞]",
            "[闭嘴]",
            "[睡]",
            "[大哭]",
            "[尴尬]",
            "[发怒]",
            "[调皮]",
            "[呲牙]",
            "[惊讶]",
            "[难过]",
            "[酷]",
            "[冷汗]",
            "[抓狂]",
            "[吐]",
            "[偷笑]",
            "[愉快]",
            "[白眼]",
            "[傲慢]",
            "[饥饿]",
            "[困]",
            "[惊恐]",
            "[流汗]",
            "[憨笑]",
            "[悠闲]",
            "[奋斗]",
            "[咒骂]",
            "[疑问]",
            "[嘘]",
            "[晕]",
            "[疯了]",
            "[衰]",
            "[骷髅]",
            "[敲打]",
            "[再见]",
            "[擦汗]",
            "[抠鼻]",
            "[鼓掌]",
            "[糗大了]",
            "[坏笑]",
            "[左哼哼]",
            "[右哼哼]",
            "[哈欠]",
            "[鄙视]",
            "[委屈]",
            "[快哭了]",
            "[阴险]",
            "[亲亲]",
            "[吓]",
            "[可怜]",
            "[菜刀]",
            "[西瓜]",
            "[啤酒]",
            "[篮球]",
            "[乒乓]",
            "[咖啡]",
            "[饭]",
            "[猪头]",
            "[玫瑰]",
            "[凋谢]",
            "[嘴唇]",
            "[爱心]",
            "[心碎]",
            "[蛋糕]",
            "[闪电]",
            "[炸弹]",
            "[刀]",
            "[足球]",
            "[瓢虫]",
            "[便便]",
            "[月亮]",
            "[太阳]",
            "[礼物]",
            "[拥抱]",
            "[强]",
            "[弱]",
            "[握手]",
            "[胜利]",
            "[抱拳]",
            "[勾引]",
            "[拳头]",
            "[差劲]",
            "[爱你]",
            "[NO]",
            "[OK]",
            "[爱情]",
            "[飞吻]",
            "[跳跳]",
            "[发抖]",
            "[怄火]",
            "[转圈]",
            "[磕头]",
            "[回头]",
            "[跳绳]",
            "[投降]",
            "[激动]",
            "[乱舞]",
            "[献吻]",
            "[左太极]",
            "[右太极]",
            "\UE04A",
            "\UE049",
            "\UE04B",
            "\UE048",
            "\UE13D",
            "\UE443",
            "\UE43C",
            "\UE44B",
            "\UE04D",
            "\UE449",
            "\UE146",
            "\UE44A",
            "\UE44C",
            "\UE04A",
            "\UE44B",
            "\UE43E",
            "\UE44B",
            "\UE04C",
            "\UE335",
            "\UE024",
            "\UE025",
            "\UE026",
            "\UE027",
            "\UE028",
            "\UE029",
            "\UE02A",
            "\UE02B",
            "\UE02C",
            "\UE02D",
            "\UE02E",
            "\UE02F",
            "\UE02D",
            "\UE23F",
            "\UE240",
            "\UE241",
            "\UE242",
            "\UE243",
            "\UE244",
            "\UE245",
            "\UE246",
            "\UE247",
            "\UE248",
            "\UE249",
            "\UE24A",
            "\UE24B",
            "\UE110",
            "\UE304",
            "\UE110",
            "\UE118",
            "\UE030",
            "\UE032",
            "\UE119",
            "\UE447",
            "\UE303",
            "\UE305",
            "\UE307",
            "\UE308",
            "\UE444",
            "\UE305",
            "\UE110",
            "\UE345",
            "\UE346",
            "\UE347",
            "\UE348",
            "\UE349",
            "\UE34A",
            "\UE345",
            "\UE419",
            "\UE41B",
            "\UE41A",
            "\UE41C",
            "\UE409",
            "\UE31C",
            "\UE31D",
            "\UE31E",
            "\UE31F",
            "\UE320",
            "\UE001",
            "\UE002",
            "\UE004",
            "\UE005",
            "\UE428",
            "\UE152",
            "\UE429",
            "\UE515",
            "\UE516",
            "\UE517",
            "\UE518",
            "\UE519",
            "\UE51A",
            "\UE51B",
            "\UE51C",
            "\UE11B",
            "\UE04E",
            "\UE10C",
            "\UE12B",
            "\UE11A",
            "\UE11C",
            "\UE253",
            "\UE51E",
            "\UE51F",
            "\UE52D",
            "\UE134",
            "\UE52E",
            "\UE52F",
            "\UE530",
            "\UE526",
            "\UE527",
            "\UE528",
            "\UE529",
            "\UE10A",
            "\UE441",
            "\UE525",
            "\UE522",
            "\UE019",
            "\UE523",
            "\UE523",
            "\UE521",
            "\UE523",
            "\UE055",
            "\UE052",
            "\UE019",
            "\UE520",
            "\UE053",
            "\UE050",
            "\UE04F",
            "\UE054",
            "\UE01A",
            "\UE109",
            "\UE052",
            "\UE10B",
            "\UE051",
            "\UE524",
            "\UE52A",
            "\UE52B",
            "\UE52C",
            "\UE531",
            "\UE536",
            "\UE10B",
            "\UE059",
            "\UE403",
            "\UE410",
            "\UE058",
            "\UE406",
            "\UE40F",
            "\UE40E",
            "\UE106",
            "\UE404",
            "\UE105",
            "\UE409",
            "\UE056",
            "\UE418",
            "\UE417",
            "\UE40C",
            "\UE40D",
            "\UE057",
            "\UE415",
            "\UE40A",
            "\UE404",
            "\UE412",
            "\UE056",
            "\UE414",
            "\UE415",
            "\UE413",
            "\UE411",
            "\UE40B",
            "\UE406",
            "\UE416",
            "\UE40A",
            "\UE407",
            "\UE403",
            "\UE107",
            "\UE408",
            "\UE402",
            "\UE108",
            "\UE401",
            "\UE406",
            "\UE405",
            "\UE057",
            "\UE404",
            "\UE412",
            "\UE418",
            "\UE106",
            "\UE413",
            "\UE416",
            "\UE404",
            "\UE403",
            "\UE423",
            "\UE424",
            "\UE426",
            "\UE012",
            "\UE427",
            "\UE403",
            "\UE416",
            "\UE41D",
            "\UE036",
            "\UE036",
            "\UE038",
            "\UE153",
            "\UE155",
            "\UE14D",
            "\UE154",
            "\UE158",
            "\UE501",
            "\UE156",
            "\UE157",
            "\UE037",
            "\UE121",
            "\UE504",
            "\UE505",
            "\UE506",
            "\UE508",
            "\UE202",
            "\UE30B",
            "\UE03B",
            "\UE509",
            "\UE51D",
            "\UE007",
            "\UE007",
            "\UE13E",
            "\UE31A",
            "\UE31B",
            "\UE536",
            "\UE006",
            "\UE10E",
            "\UE302",
            "\UE318",
            "\UE319",
            "\UE321",
            "\UE322",
            "\UE006",
            "\UE323",
            "\UE12F",
            "\UE149",
            "\UE14A",
            "\UE12F",
            "\UE12F",
            "\UE11D",
            "\UE116",
            "\UE113",
            "\UE23E",
            "\UE23E",
            "\UE209",
            "\UE031",
            "\UE13B",
            "\UE30F",
            "\UE532",
            "\UE533",
            "\UE534",
            "\UE535",
            "\UE314",
            "\UE112",
            "\UE34B",
            "\UE033",
            "\UE448",
            "\UE143",
            "\UE117",
            "\UE310",
            "\UE312",
            "\UE436",
            "\UE438",
            "\UE439",
            "\UE43A",
            "\UE43B",
            "\UE440",
            "\UE442",
            "\UE445",
            "\UE446",
            "\UE009",
            "\UE009",
            "\UE00A",
            "\UE104",
            "\UE301",
            "\UE00B",
            "\UE103",
            "\UE103",
            "\UE103",
            "\UE101",
            "\UE101",
            "\UE102",
            "\UE142",
            "\UE317",
            "\UE14B",
            "\UE112",
            "\UE103",
            "\UE11F",
            "\UE00C",
            "\UE301",
            "\UE11E",
            "\UE316",
            "\UE316",
            "\UE126",
            "\UE127",
            "\UE313",
            "\UE301",
            "\UE301",
            "\UE148",
            "\UE148",
            "\UE148",
            "\UE148",
            "\UE148",
            "\UE148",
            "\UE148",
            "\UE148",
            "\UE301",
            "\UE14A",
            "\UE14A",
            "\UE148",
            "\UE148",
            "\UE301",
            "\UE016",
            "\UE014",
            "\UE015",
            "\UE018",
            "\UE013",
            "\UE42A",
            "\UE132",
            "\UE115",
            "\UE017",
            "\UE131",
            "\UE42B",
            "\UE42D",
            "\UE01E",
            "\UE434",
            "\UE434",
            "\UE435",
            "\UE01F",
            "\UE01B",
            "\UE42E",
            "\UE159",
            "\UE150",
            "\UE202",
            "\UE01D",
            "\UE01C",
            "\UE039",
            "\UE10D",
            "\UE135",
            "\UE15A",
            "\UE42F",
            "\UE430",
            "\UE431",
            "\UE432",
            "\UE03A",
            "\UE14F",
            "\UE14E",
            "\UE137",
            "\UE432",
            "\UE123",
            "\UE122",
            "\UE124",
            "\UE433",
            "\UE019",
            "\UE03C",
            "\UE03D",
            "\UE507",
            "\UE30A",
            "\UE502",
            "\UE503",
            "\UE125",
            "\UE324",
            "\UE503",
            "\UE12D",
            "\UE130",
            "\UE133",
            "\UE42C",
            "\UE03E",
            "\UE326",
            "\UE040",
            "\UE041",
            "\UE042",
            "\UE326",
            "\UE12C",
            "\UE008",
            "\UE03D",
            "\UE12A",
            "\UE128",
            "\UE129",
            "\UE003",
            "\UE103",
            "\UE034",
            "\UE035",
            "\UE111",
            "\UE306",
            "\UE425",
            "\UE43D",
            "\UE207",
            "\UE24E",
            "\UE24F",
            "\UE537",
            "\UE20B",
            "\UE250",
            "\UE251",
            "\UE120",
            "\UE342",
            "\UE046",
            "\UE340",
            "\UE339",
            "\UE147",
            "\UE33A",
            "\UE33B",
            "\UE33C",
            "\UE33D",
            "\UE33E",
            "\UE33F",
            "\UE341",
            "\UE343",
            "\UE344",
            "\UE34C",
            "\UE34D",
            "\UE43F",
            "\UE043",
            "\UE045",
            "\UE044",
            "\UE047",
            "\UE338",
            "\UE30B",
            "\UE044",
            "\UE30C",
            "\UE044",
            "\UE236",
            "\UE238",
            "\UE237",
            "\UE239",
            "\UE236",
            "\UE238",
            "\UE232",
            "\UE233",
            "\UE234",
            "\UE235",
            "\UE23A",
            "\UE23B",
            "\UE23C",
            "\UE23D",
            "\UE332",
            "\UE333",
            "\UE333",
            "\UE021",
            "\UE020",
            "\UE336",
            "\UE337",
            "\UE211",
            "\UE022",
            "\UE327",
            "\UE023",
            "\UE327",
            "\UE327",
            "\UE328",
            "\UE329",
            "\UE32A",
            "\UE32B",
            "\UE32C",
            "\UE32D",
            "\UE437",
            "\UE327",
            "\UE204",
            "\UE20C",
            "\UE20E",
            "\UE20D",
            "\UE20F",
            "\UE30E",
            "\UE208",
            "\UE20A",
            "\UE252",
            "\UE137",
            "\UE136",
            "\UE201",
            "\UE138",
            "\UE139",
            "\UE13F",
            "\UE151",
            "\UE140",
            "\UE309",
            "\UE13A",
            "\UE214",
            "\UE229",
            "\UE212",
            "\UE24D",
            "\UE213",
            "\UE12E",
            "\UE203",
            "\UE228",
            "\UE22B",
            "\UE22A",
            "\UE215",
            "\UE216",
            "\UE217",
            "\UE218",
            "\UE227",
            "\UE22C",
            "\UE22D",
            "\UE315",
            "\UE30D",
            "\UE226",
            "\UE333",
            "\UE10F",
            "\UE334",
            "\UE311",
            "\UE13C",
            "\UE331",
            "\UE331",
            "\UE330",
            "\UE05A",
            "\UE14C",
            "\UE407",
            "\UE32E",
            "\UE205",
            "\UE206",
            "\UE219",
            "\UE219",
            "\UE219",
            "\UE21A",
            "\UE21A",
            "\UE21B",
            "\UE32F",
            "\UE21B",
            "\UE21A",
            "\UE21B",
            "\UE21A",
            "\UE21B",
            "\UE21A",
            "\UE21B",
            "\UE21A",
            "\UE21B",
            "\UE21B",
            "\UE21B",
            "\UE21B",
            "\UE32E",
            "\UE141",
            "\UE114",
            "\UE114",
            "\UE144",
            "\UE145",
            "\UE144",
            "\UE144",
            "\UE03F",
            "\UE325",
            "\UE235",
            "\UE24C",
            "\UE010",
            "\UE012",
            "\UE011",
            "\UE00D",
            "\UE00E",
            "\UE00F",
            "\UE22E",
            "\UE22F",
            "\UE230",
            "\UE231",
            "\UE41E",
            "\UE41F",
            "\UE420",
            "\UE421",
            "\UE422" ];
        return $arr[mt_rand(0, count($arr)-1)];
    }
    public function test(){


        //http://qun.wqchat.com/index.php?m=wingpcnew&a=api_getkwd
        //
//       $tes = $this->http_request(
//          'http://qun.wqchat.com/index.php?m=wingpcnew&a=api_getgroupinfo&vol=Dev3.26',
//            [
//                'u'=>'126748',
//'wxuin'=>'wxid_cxrh6lfe9hvm12',
//'wxuin_admin'=>'fyxgzs',
//'nickname'=>'',
//'roomid'=>'13680952411@chatroom',
//'gname'=>'\u6211\u7684\u670B\u53CB\u5708',
//'appopen'=>'on',
//'vol'=>'Dev3.26'
//  ],
//            ['Cookie: think_language=zh-cn; PHPSESSID=nm9b169hic43s6uhfkcq65qeo2']
//        );

        echo '>';
        $tes = $this->http_request(
            'http://qun.wqchat.com/index.php?m=wingpcnew&a=api_get_dev',
            [
                'apikey'=>'',
                'wxuin'=>'123',
                'vol'=>'Dev3.26'
            ],
            ['User-Agent: Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)',
                'Cookie: think_language=zh-cn']
        );
//        POST /index.php?m=wingpcnew&a=api_get_dev HTTP/1.1
//Accept: */*
//Referer: http://qun.wqchat.com/index.php?m=wingpcnew&a=api_get_dev
//Accept-Language: zh-cn
//Content-Type: application/x-www-form-urlencoded
//User-Agent: Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)
//Host: qun.wqchat.com
//Content-Length: 29
//Cache-Control: no-cache
//Cookie: think_language=zh-cn
//
//apikey=&wxuin=123&vol=Dev3.26


//        $tes = $this->http_request(
//            'http://qun.wqchat.com/index.php?m=wingpcnew&a=api_login&vol=Dev3.26',
//            [
//                'wname'=>'moyi@mymoyi.cn',
//                'wpwd'=>'821121',
//                'op'=>'login'
//            ],
//            ['Cookie: think_language=zh-cn; PHPSESSID=7i7b2lnkmv0ut53qvh626ektm4']
//        );
//
//        $tes = $this->http_request(
//            'http://qun.wqchat.com/index.php?m=wingpcnew&a=api_reg_login&vol=Dev3.26',
//            [
//                'u'=>'126748',
//                'wxuin'=>'wxid_cxrh6lfe9hvm12',
//                'wxuin2'=>'molegeyi',
//                'wname'=>'moyi@mymoyi.cn',
//                'nickname'=>'\u9ED8\u4E86\u4E2A\u6BC5',
//                'wpwd'=>'821121',
//                'tel'=>'',
//                'op'=>'fresh',
//                'voltype'=>'wingpc',
//                'vol'=>'Dev3.26'
//            ],
//            ['Cookie: think_language=zh-cn; PHPSESSID=7i7b2lnkmv0ut53qvh626ektm4']
//        );

        print_r($tes);
//        PHPSESSID=nm9b169hic43s6uhfkcq65qeo2
        exit();

//        POST /index.php?m=wingpcnew&a=api_login&vol=Dev3.26 HTTP/1.1
//Accept: */*
//Referer: http://qun.wqchat.com/index.php?m=wingpcnew&a=api_login&vol=Dev3.26
//Accept-Language: zh-cn
//Content-Type: application/x-www-form-urlencoded
//User-Agent: Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)
//Host: qun.wqchat.com
//Content-Length: 41
//Cache-Control: no-cache
//Cookie: think_language=zh-cn; PHPSESSID=7i7b2lnkmv0ut53qvh626ektm4
//
//wname=moyi@mymoyi.cn&wpwd=821121&op=login
//
//
//        POST /index.php?m=wingpcnew&a=api_get_dev HTTP/1.1
//Accept: */*
//Referer: http://qun.wqchat.com/index.php?m=wingpcnew&a=api_get_dev
//Accept-Language: zh-cn
//Content-Type: application/x-www-form-urlencoded
//User-Agent: Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)
//Host: qun.wqchat.com
//Content-Length: 29
//Cache-Control: no-cache
//Cookie: think_language=zh-cn
//
//apikey=&wxuin=123&vol=Dev3.26


        //
//        POST /index.php?m=wingpcnew&a=api_getgroupinfo&vol=Dev3.26 HTTP/1.1
//Accept: */*
//Referer: http://qun.wqchat.com/index.php?m=wingpcnew&a=api_getgroupinfo&vol=Dev3.26
//Accept-Language: zh-cn
//Content-Type: application/x-www-form-urlencoded
//User-Agent: Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)
//Host: qun.wqchat.com
//Content-Length: 151
//Cache-Control: no-cache
//Cookie: think_language=zh-cn; PHPSESSID=v5vgl3m5v1kvbqkr3qj02isld2
//
//u=126748&wxuin=wxid_cxrh6lfe9hvm12&wxuin_admin=fyxgzs&nickname=&roomid=13680952411@chatroom&gname=\u6211\u7684\u670B\u53CB\u5708&appopen=on&vol=Dev3.26


//        POST /index.php?m=wingpcnew&a=api_reg_login&vol=Dev3.26 HTTP/1.1
//Accept: */*
//Referer: http://qun.wqchat.com/index.php?m=wingpcnew&a=api_reg_login&vol=Dev3.26
//Accept-Language: zh-cn
//Content-Type: application/x-www-form-urlencoded
//User-Agent: Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)
//Host: qun.wqchat.com
//Content-Length: 158
//Cache-Control: no-cache
//Cookie: think_language=zh-cn; PHPSESSID=v5vgl3m5v1kvbqkr3qj02isld2
//
//u=126748&wxuin=wxid_cxrh6lfe9hvm12&wxuin2=molegeyi&wname=moyi@mymoyi.cn&nickname=\u9ED8\u4E86\u4E2A\u6BC5&wpwd=821121&tel=&op=fresh&voltype=wingpc&vol=Dev3.26
//
//        POST /index.php?m=wingpcnew&a=api_reg_login&vol=Dev3.26 HTTP/1.1
//Accept: */*
//Referer: http://qun.wqchat.com/index.php?m=wingpcnew&a=api_reg_login&vol=Dev3.26
//Accept-Language: zh-cn
//Content-Type: application/x-www-form-urlencoded
//User-Agent: Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)
//Host: qun.wqchat.com
//Content-Length: 158
//Cache-Control: no-cache
//Cookie: think_language=zh-cn; PHPSESSID=nm9b169hic43s6uhfkcq65qeo2
//
//u=126748&wxuin=wxid_cxrh6lfe9hvm12&wxuin2=molegeyi&wname=moyi@mymoyi.cn&nickname=\u9ED8\u4E86\u4E2A\u6BC5&wpwd=821121&tel=&op=fresh&voltype=wingpc&vol=Dev3.26
//
        print_r(json_encode(get_addon_config('moyicosmic',false)));
//        print_r(2);
        exit();
        $this->mosheng();



        exit();

//         print_r( $this->emmoji());
//        exit();
//        print_r(count($arr)-1);

        $text = "Don& #39;t hang your sadness on your face, it will look very fruitless. 别把难过挂在脸上，那样会显得很没有出息;来溜达溜达 ✨✨✨✨✨娃大王💔,送人玫瑰手留余香，臭妹妹dd 我\U0001F60A，长这么大还没遇到过不喜欢草莓的人呢，难怪大家都喜欢种草莓🍓";
        $text = str_replace('💔','[心碎]',$text);
        $text = str_replace('⚠️','\UE252',$text);
        $text = str_replace('🖐','\UE41E',$text);
        $text = str_replace('\U0002600','\UE04A',$text);
        $text = str_replace('\U0002601','\UE049',$text);
        $text = str_replace('\U0002614','\UE04B',$text);
        $text = str_replace('\U00026C4','\UE048',$text);
        $text = str_replace('\U00026A1','\UE13D',$text);
        $text = str_replace('\U0001F300','\UE443',$text);
        $text = str_replace('\U0001F302','\UE43C',$text);
        $text = str_replace('\U0001F303','\UE44B',$text);
        $text = str_replace('\U0001F304','\UE04D',$text);
        $text = str_replace('\U0001F305','\UE449',$text);
        $text = str_replace('\U0001F306','\UE146',$text);
        $text = str_replace('\U0001F307','\UE44A',$text);
        $text = str_replace('\U0001F308','\UE44C',$text);
        $text = str_replace('\U00026C5','\UE04A',$text);
        $text = str_replace('\U0001F309','\UE44B',$text);
        $text = str_replace('\U0001F30A','\UE43E',$text);
        $text = str_replace('\U0001F30C','\UE44B',$text);
        $text = str_replace('\U0001F314','\UE04C',$text);
        $text = str_replace('\U0001F31F','\UE335',$text);
        $text = str_replace('\U0001F550','\UE024',$text);
        $text = str_replace('\U0001F551','\UE025',$text);
        $text = str_replace('\U0001F552','\UE026',$text);
        $text = str_replace('\U0001F553','\UE027',$text);
        $text = str_replace('\U0001F554','\UE028',$text);
        $text = str_replace('\U0001F555','\UE029',$text);
        $text = str_replace('\U0001F556','\UE02A',$text);
        $text = str_replace('\U0001F557','\UE02B',$text);
        $text = str_replace('\U0001F558','\UE02C',$text);
        $text = str_replace('\U0001F559','\UE02D',$text);
        $text = str_replace('\U0001F55A','\UE02E',$text);
        $text = str_replace('\U0001F55B','\UE02F',$text);
        $text = str_replace('\U00023F0','\UE02D',$text);
        $text = str_replace('\U0002648','\UE23F',$text);
        $text = str_replace('\U0002649','\UE240',$text);
        $text = str_replace('\U000264A','\UE241',$text);
        $text = str_replace('\U000264B','\UE242',$text);
        $text = str_replace('\U000264C','\UE243',$text);
        $text = str_replace('\U000264D','\UE244',$text);
        $text = str_replace('\U000264E','\UE245',$text);
        $text = str_replace('\U000264F','\UE246',$text);
        $text = str_replace('\U0002650','\UE247',$text);
        $text = str_replace('\U0002651','\UE248',$text);
        $text = str_replace('\U0002652','\UE249',$text);
        $text = str_replace('\U0002653','\UE24A',$text);
        $text = str_replace('\U00026CE','\UE24B',$text);
        $text = str_replace('\U0001F340','\UE110',$text);
        $text = str_replace('\U0001F337','\UE304',$text);
        $text = str_replace('\U0001F331','\UE110',$text);
        $text = str_replace('\U0001F341','\UE118',$text);
        $text = str_replace('\U0001F338','\UE030',$text);
        $text = str_replace('\U0001F339','\UE032',$text);
        $text = str_replace('\U0001F342','\UE119',$text);
        $text = str_replace('\U0001F343','\UE447',$text);
        $text = str_replace('\U0001F33A','\UE303',$text);
        $text = str_replace('\U0001F33B','\UE305',$text);
        $text = str_replace('\U0001F334','\UE307',$text);
        $text = str_replace('\U0001F335','\UE308',$text);
        $text = str_replace('\U0001F33E','\UE444',$text);
        $text = str_replace('\U0001F33C','\UE305',$text);
        $text = str_replace('\U0001F33F','\UE110',$text);
        $text = str_replace('\U0001F34E','\UE345',$text);
        $text = str_replace('\U0001F34A','\UE346',$text);
        $text = str_replace('\U0001F353','\UE347',$text);
        $text = str_replace('\U0001F349','\UE348',$text);
        $text = str_replace('\U0001F345','\UE349',$text);
        $text = str_replace('\U0001F346','\UE34A',$text);
        $text = str_replace('\U0001F34F','\UE345',$text);
        $text = str_replace('\U0001F440','\UE419',$text);
        $text = str_replace('\U0001F442','\UE41B',$text);
        $text = str_replace('\U0001F443','\UE41A',$text);
        $text = str_replace('\U0001F444','\UE41C',$text);
        $text = str_replace('\U0001F445','\UE409',$text);
        $text = str_replace('\U0001F484','\UE31C',$text);
        $text = str_replace('\U0001F485','\UE31D',$text);
        $text = str_replace('\U0001F486','\UE31E',$text);
        $text = str_replace('\U0001F487','\UE31F',$text);
        $text = str_replace('\U0001F488','\UE320',$text);
        $text = str_replace('\U0001F466','\UE001',$text);
        $text = str_replace('\U0001F467','\UE002',$text);
        $text = str_replace('\U0001F468','\UE004',$text);
        $text = str_replace('\U0001F469','\UE005',$text);
        $text = str_replace('\U0001F46B','\UE428',$text);
        $text = str_replace('\U0001F46E','\UE152',$text);
        $text = str_replace('\U0001F46F','\UE429',$text);
        $text = str_replace('\U0001F471','\UE515',$text);
        $text = str_replace('\U0001F472','\UE516',$text);
        $text = str_replace('\U0001F473','\UE517',$text);
        $text = str_replace('\U0001F474','\UE518',$text);
        $text = str_replace('\U0001F475','\UE519',$text);
        $text = str_replace('\U0001F476','\UE51A',$text);
        $text = str_replace('\U0001F477','\UE51B',$text);
        $text = str_replace('\U0001F478','\UE51C',$text);
        $text = str_replace('\U0001F47B','\UE11B',$text);
        $text = str_replace('\U0001F47C','\UE04E',$text);
        $text = str_replace('\U0001F47D','\UE10C',$text);
        $text = str_replace('\U0001F47E','\UE12B',$text);
        $text = str_replace('\U0001F47F','\UE11A',$text);
        $text = str_replace('\U0001F480','\UE11C',$text);
        $text = str_replace('\U0001F481','\UE253',$text);
        $text = str_replace('\U0001F482','\UE51E',$text);
        $text = str_replace('\U0001F483','\UE51F',$text);
        $text = str_replace('\U0001F40D','\UE52D',$text);
        $text = str_replace('\U0001F40E','\UE134',$text);
        $text = str_replace('\U0001F414','\UE52E',$text);
        $text = str_replace('\U0001F417','\UE52F',$text);
        $text = str_replace('\U0001F42B','\UE530',$text);
        $text = str_replace('\U0001F418','\UE526',$text);
        $text = str_replace('\U0001F428','\UE527',$text);
        $text = str_replace('\U0001F412','\UE528',$text);
        $text = str_replace('\U0001F411','\UE529',$text);
        $text = str_replace('\U0001F419','\UE10A',$text);
        $text = str_replace('\U0001F41A','\UE441',$text);
        $text = str_replace('\U0001F41B','\UE525',$text);
        $text = str_replace('\U0001F420','\UE522',$text);
        $text = str_replace('\U0001F421','\UE019',$text);
        $text = str_replace('\U0001F424','\UE523',$text);
        $text = str_replace('\U0001F425','\UE523',$text);
        $text = str_replace('\U0001F426','\UE521',$text);
        $text = str_replace('\U0001F423','\UE523',$text);
        $text = str_replace('\U0001F427','\UE055',$text);
        $text = str_replace('\U0001F429','\UE052',$text);
        $text = str_replace('\U0001F41F','\UE019',$text);
        $text = str_replace('\U0001F42C','\UE520',$text);
        $text = str_replace('\U0001F42D','\UE053',$text);
        $text = str_replace('\U0001F42F','\UE050',$text);
        $text = str_replace('\U0001F431','\UE04F',$text);
        $text = str_replace('\U0001F433','\UE054',$text);
        $text = str_replace('\U0001F434','\UE01A',$text);
        $text = str_replace('\U0001F435','\UE109',$text);
        $text = str_replace('\U0001F436','\UE052',$text);
        $text = str_replace('\U0001F437','\UE10B',$text);
        $text = str_replace('\U0001F43B','\UE051',$text);
        $text = str_replace('\U0001F439','\UE524',$text);
        $text = str_replace('\U0001F43A','\UE52A',$text);
        $text = str_replace('\U0001F42E','\UE52B',$text);
        $text = str_replace('\U0001F430','\UE52C',$text);
        $text = str_replace('\U0001F438','\UE531',$text);
        $text = str_replace('\U0001F43E','\UE536',$text);
        $text = str_replace('\U0001F43D','\UE10B',$text);
        $text = str_replace('\U0001F620','\UE059',$text);
        $text = str_replace('\U0001F629','\UE403',$text);
        $text = str_replace('\U0001F632','\UE410',$text);
        $text = str_replace('\U0001F61E','\UE058',$text);
        $text = str_replace('\U0001F635','\UE406',$text);
        $text = str_replace('\U0001F630','\UE40F',$text);
        $text = str_replace('\U0001F612','\UE40E',$text);
        $text = str_replace('\U0001F60D','\UE106',$text);
        $text = str_replace('\U0001F624','\UE404',$text);
        $text = str_replace('\U0001F61C','\UE105',$text);
        $text = str_replace('\U0001F61D','\UE409',$text);
        $text = str_replace('\U0001F60B','\UE056',$text);
        $text = str_replace('\U0001F618','\UE418',$text);
        $text = str_replace('\U0001F61A','\UE417',$text);
        $text = str_replace('\U0001F637','\UE40C',$text);
        $text = str_replace('\U0001F633','\UE40D',$text);
        $text = str_replace('\U0001F603','\UE057',$text);
        $text = str_replace('\U0001F605','\UE415',$text);
        $text = str_replace('\U0001F606','\UE40A',$text);
        $text = str_replace('\U0001F601','\UE404',$text);
        $text = str_replace('\U0001F602','\UE412',$text);
        $text = str_replace('\U0001F60A','\UE056',$text);
        $text = str_replace('\U000263A','\UE414',$text);
        $text = str_replace('\U0001F604','\UE415',$text);
        $text = str_replace('\U0001F622','\UE413',$text);
        $text = str_replace('\U0001F62D','\UE411',$text);
        $text = str_replace('\U0001F628','\UE40B',$text);
        $text = str_replace('\U0001F623','\UE406',$text);
        $text = str_replace('\U0001F621','\UE416',$text);
        $text = str_replace('\U0001F60C','\UE40A',$text);
        $text = str_replace('\U0001F616','\UE407',$text);
        $text = str_replace('\U0001F614','\UE403',$text);
        $text = str_replace('\U0001F631','\UE107',$text);
        $text = str_replace('\U0001F62A','\UE408',$text);
        $text = str_replace('\U0001F60F','\UE402',$text);
        $text = str_replace('\U0001F613','\UE108',$text);
        $text = str_replace('\U0001F625','\UE401',$text);
        $text = str_replace('\U0001F62B','\UE406',$text);
        $text = str_replace('\U0001F609','\UE405',$text);
        $text = str_replace('\U0001F63A','\UE057',$text);
        $text = str_replace('\U0001F638','\UE404',$text);
        $text = str_replace('\U0001F639','\UE412',$text);
        $text = str_replace('\U0001F63D','\UE418',$text);
        $text = str_replace('\U0001F63B','\UE106',$text);
        $text = str_replace('\U0001F63F','\UE413',$text);
        $text = str_replace('\U0001F63E','\UE416',$text);
        $text = str_replace('\U0001F63C','\UE404',$text);
        $text = str_replace('\U0001F640','\UE403',$text);
        $text = str_replace('\U0001F645','\UE423',$text);
        $text = str_replace('\U0001F646','\UE424',$text);
        $text = str_replace('\U0001F647','\UE426',$text);
        $text = str_replace('\U0001F64B','\UE012',$text);
        $text = str_replace('\U0001F64C','\UE427',$text);
        $text = str_replace('\U0001F64D','\UE403',$text);
        $text = str_replace('\U0001F64E','\UE416',$text);
        $text = str_replace('\U0001F64F','\UE41D',$text);
        $text = str_replace('\U0001F3E0','\UE036',$text);
        $text = str_replace('\U0001F3E1','\UE036',$text);
        $text = str_replace('\U0001F3E2','\UE038',$text);
        $text = str_replace('\U0001F3E3','\UE153',$text);
        $text = str_replace('\U0001F3E5','\UE155',$text);
        $text = str_replace('\U0001F3E6','\UE14D',$text);
        $text = str_replace('\U0001F3E7','\UE154',$text);
        $text = str_replace('\U0001F3E8','\UE158',$text);
        $text = str_replace('\U0001F3E9','\UE501',$text);
        $text = str_replace('\U0001F3EA','\UE156',$text);
        $text = str_replace('\U0001F3EB','\UE157',$text);
        $text = str_replace('\U00026EA','\UE037',$text);
        $text = str_replace('\U00026F2','\UE121',$text);
        $text = str_replace('\U0001F3EC','\UE504',$text);
        $text = str_replace('\U0001F3EF','\UE505',$text);
        $text = str_replace('\U0001F3F0','\UE506',$text);
        $text = str_replace('\U0001F3ED','\UE508',$text);
        $text = str_replace('\U0002693','\UE202',$text);
        $text = str_replace('\U0001F3EE','\UE30B',$text);
        $text = str_replace('\U0001F5FB','\UE03B',$text);
        $text = str_replace('\U0001F5FC','\UE509',$text);
        $text = str_replace('\U0001F5FD','\UE51D',$text);
        $text = str_replace('\U0001F45E','\UE007',$text);
        $text = str_replace('\U0001F45F','\UE007',$text);
        $text = str_replace('\U0001F460','\UE13E',$text);
        $text = str_replace('\U0001F461','\UE31A',$text);
        $text = str_replace('\U0001F462','\UE31B',$text);
        $text = str_replace('\U0001F463','\UE536',$text);
        $text = str_replace('\U0001F455','\UE006',$text);
        $text = str_replace('\U0001F451','\UE10E',$text);
        $text = str_replace('\U0001F454','\UE302',$text);
        $text = str_replace('\U0001F452','\UE318',$text);
        $text = str_replace('\U0001F457','\UE319',$text);
        $text = str_replace('\U0001F458','\UE321',$text);
        $text = str_replace('\U0001F459','\UE322',$text);
        $text = str_replace('\U0001F45A','\UE006',$text);
        $text = str_replace('\U0001F45C','\UE323',$text);
        $text = str_replace('\U0001F4B0','\UE12F',$text);
        $text = str_replace('\U0001F4B1','\UE149',$text);
        $text = str_replace('\U0001F4B9','\UE14A',$text);
        $text = str_replace('\U0001F4B2','\UE12F',$text);
        $text = str_replace('\U0001F4B5','\UE12F',$text);
        $text = str_replace('1F1E81F1F3','\UE513',$text);
        $text = str_replace('1F1E91F1EA','\UE50E',$text);
        $text = str_replace('1F1EA1F1F8','\UE511',$text);
        $text = str_replace('1F1EB1F1F7','\UE50D',$text);
        $text = str_replace('1F1EC1F1E7','\UE510',$text);
        $text = str_replace('1F1EE1F1F9','\UE50F',$text);
        $text = str_replace('1F1EF1F1F5','\UE50B',$text);
        $text = str_replace('1F1F01F1F7','\UE514',$text);
        $text = str_replace('1F1F71F1FA','\UE512',$text);
        $text = str_replace('1F1FA1F1F8','\UE50C',$text);
        $text = str_replace('\U0001F525','\UE11D',$text);
        $text = str_replace('\U0001F528','\UE116',$text);
        $text = str_replace('\U0001F52B','\UE113',$text);
        $text = str_replace('\U0001F52E','\UE23E',$text);
        $text = str_replace('\U0001F52F','\UE23E',$text);
        $text = str_replace('\U0001F530','\UE209',$text);
        $text = str_replace('\U0001F531','\UE031',$text);
        $text = str_replace('\U0001F489','\UE13B',$text);
        $text = str_replace('\U0001F48A','\UE30F',$text);
        $text = str_replace('\U0001F170','\UE532',$text);
        $text = str_replace('\U0001F171','\UE533',$text);
        $text = str_replace('\U0001F18E','\UE534',$text);
        $text = str_replace('\U0001F17E','\UE535',$text);
        $text = str_replace('\U0001F380','\UE314',$text);
        $text = str_replace('\U0001F381','\UE112',$text);
        $text = str_replace('\U0001F382','\UE34B',$text);
        $text = str_replace('\U0001F384','\UE033',$text);
        $text = str_replace('\U0001F385','\UE448',$text);
        $text = str_replace('\U0001F38C','\UE143',$text);
        $text = str_replace('\U0001F386','\UE117',$text);
        $text = str_replace('\U0001F388','\UE310',$text);
        $text = str_replace('\U0001F389','\UE312',$text);
        $text = str_replace('\U0001F38D','\UE436',$text);
        $text = str_replace('\U0001F38E','\UE438',$text);
        $text = str_replace('\U0001F393','\UE439',$text);
        $text = str_replace('\U0001F392','\UE43A',$text);
        $text = str_replace('\U0001F38F','\UE43B',$text);
        $text = str_replace('\U0001F387','\UE440',$text);
        $text = str_replace('\U0001F390','\UE442',$text);
        $text = str_replace('\U0001F383','\UE445',$text);
        $text = str_replace('\U0001F391','\UE446',$text);
        $text = str_replace('\U000260E','\UE009',$text);
        $text = str_replace('\U0001F4DE','\UE009',$text);
        $text = str_replace('\U0001F4F1','\UE00A',$text);
        $text = str_replace('\U0001F4F2','\UE104',$text);
        $text = str_replace('\U0001F4DD','\UE301',$text);
        $text = str_replace('\U0001F4E0','\UE00B',$text);
        $text = str_replace('\U0002709','\UE103',$text);
        $text = str_replace('\U0001F4E8','\UE103',$text);
        $text = str_replace('\U0001F4E9','\UE103',$text);
        $text = str_replace('\U0001F4EA','\UE101',$text);
        $text = str_replace('\U0001F4EB','\UE101',$text);
        $text = str_replace('\U0001F4EE','\UE102',$text);
        $text = str_replace('\U0001F4E2','\UE142',$text);
        $text = str_replace('\U0001F4E3','\UE317',$text);
        $text = str_replace('\U0001F4E1','\UE14B',$text);
        $text = str_replace('\U0001F4E6','\UE112',$text);
        $text = str_replace('\U0001F4E7','\UE103',$text);
        $text = str_replace('\U0001F4BA','\UE11F',$text);
        $text = str_replace('\U0001F4BB','\UE00C',$text);
        $text = str_replace('\U000270F','\UE301',$text);
        $text = str_replace('\U0001F4BC','\UE11E',$text);
        $text = str_replace('\U0001F4BD','\UE316',$text);
        $text = str_replace('\U0001F4BE','\UE316',$text);
        $text = str_replace('\U0001F4BF','\UE126',$text);
        $text = str_replace('\U0001F4C0','\UE127',$text);
        $text = str_replace('\U0002702','\UE313',$text);
        $text = str_replace('\U0001F4C3','\UE301',$text);
        $text = str_replace('\U0001F4C4','\UE301',$text);
        $text = str_replace('\U0001F4D3','\UE148',$text);
        $text = str_replace('\U0001F4D6','\UE148',$text);
        $text = str_replace('\U0001F4D4','\UE148',$text);
        $text = str_replace('\U0001F4D5','\UE148',$text);
        $text = str_replace('\U0001F4D7','\UE148',$text);
        $text = str_replace('\U0001F4D8','\UE148',$text);
        $text = str_replace('\U0001F4D9','\UE148',$text);
        $text = str_replace('\U0001F4DA','\UE148',$text);
        $text = str_replace('\U0001F4CB','\UE301',$text);
        $text = str_replace('\U0001F4CA','\UE14A',$text);
        $text = str_replace('\U0001F4C8','\UE14A',$text);
        $text = str_replace('\U0001F4C7','\UE148',$text);
        $text = str_replace('\U0001F4D2','\UE148',$text);
        $text = str_replace('\U0001F4D1','\UE301',$text);
        $text = str_replace('\U00026BE','\UE016',$text);
        $text = str_replace('\U00026F3','\UE014',$text);
        $text = str_replace('\U0001F3BE','\UE015',$text);
        $text = str_replace('\U00026BD','\UE018',$text);
        $text = str_replace('\U0001F3BF','\UE013',$text);
        $text = str_replace('\U0001F3C0','\UE42A',$text);
        $text = str_replace('\U0001F3C1','\UE132',$text);
        $text = str_replace('\U0001F3C3','\UE115',$text);
        $text = str_replace('\U0001F3C4','\UE017',$text);
        $text = str_replace('\U0001F3C6','\UE131',$text);
        $text = str_replace('\U0001F3C8','\UE42B',$text);
        $text = str_replace('\U0001F3CA','\UE42D',$text);
        $text = str_replace('\U0001F683','\UE01E',$text);
        $text = str_replace('\U0001F687','\UE434',$text);
        $text = str_replace('\U00024C2','\UE434',$text);
        $text = str_replace('\U0001F684','\UE435',$text);
        $text = str_replace('\U0001F685','\UE01F',$text);
        $text = str_replace('\U0001F697','\UE01B',$text);
        $text = str_replace('\U0001F699','\UE42E',$text);
        $text = str_replace('\U0001F68C','\UE159',$text);
        $text = str_replace('\U0001F68F','\UE150',$text);
        $text = str_replace('\U0001F6A2','\UE202',$text);
        $text = str_replace('\U0002708','\UE01D',$text);
        $text = str_replace('\U00026F5','\UE01C',$text);
        $text = str_replace('\U0001F689','\UE039',$text);
        $text = str_replace('\U0001F680','\UE10D',$text);
        $text = str_replace('\U0001F6A4','\UE135',$text);
        $text = str_replace('\U0001F695','\UE15A',$text);
        $text = str_replace('\U0001F69A','\UE42F',$text);
        $text = str_replace('\U0001F692','\UE430',$text);
        $text = str_replace('\U0001F691','\UE431',$text);
        $text = str_replace('\U0001F693','\UE432',$text);
        $text = str_replace('\U00026FD','\UE03A',$text);
        $text = str_replace('\U0001F17F','\UE14F',$text);
        $text = str_replace('\U0001F6A5','\UE14E',$text);
        $text = str_replace('\U0001F6A7','\UE137',$text);
        $text = str_replace('\U0001F6A8','\UE432',$text);
        $text = str_replace('\U0002668','\UE123',$text);
        $text = str_replace('\U00026FA','\UE122',$text);
        $text = str_replace('\U0001F3A1','\UE124',$text);
        $text = str_replace('\U0001F3A2','\UE433',$text);
        $text = str_replace('\U0001F3A3','\UE019',$text);
        $text = str_replace('\U0001F3A4','\UE03C',$text);
        $text = str_replace('\U0001F3A5','\UE03D',$text);
        $text = str_replace('\U0001F3A6','\UE507',$text);
        $text = str_replace('\U0001F3A7','\UE30A',$text);
        $text = str_replace('\U0001F3A8','\UE502',$text);
        $text = str_replace('\U0001F3A9','\UE503',$text);
        $text = str_replace('\U0001F3AB','\UE125',$text);
        $text = str_replace('\U0001F3AC','\UE324',$text);
        $text = str_replace('\U0001F3AD','\UE503',$text);
        $text = str_replace('\U0001F004','\UE12D',$text);
        $text = str_replace('\U0001F3AF','\UE130',$text);
        $text = str_replace('\U0001F3B0','\UE133',$text);
        $text = str_replace('\U0001F3B1','\UE42C',$text);
        $text = str_replace('\U0001F3B5','\UE03E',$text);
        $text = str_replace('\U0001F3B6','\UE326',$text);
        $text = str_replace('\U0001F3B7','\UE040',$text);
        $text = str_replace('\U0001F3B8','\UE041',$text);
        $text = str_replace('\U0001F3BA','\UE042',$text);
        $text = str_replace('\U0001F3BC','\UE326',$text);
        $text = str_replace('\U000303D','\UE12C',$text);
        $text = str_replace('\U0001F4F7','\UE008',$text);
        $text = str_replace('\U0001F4F9','\UE03D',$text);
        $text = str_replace('\U0001F4FA','\UE12A',$text);
        $text = str_replace('\U0001F4FB','\UE128',$text);
        $text = str_replace('\U0001F4FC','\UE129',$text);
        $text = str_replace('\U0001F48B','\UE003',$text);
        $text = str_replace('\U0001F48C','\UE103',$text);
        $text = str_replace('\U0001F48D','\UE034',$text);
        $text = str_replace('\U0001F48E','\UE035',$text);
        $text = str_replace('\U0001F48F','\UE111',$text);
        $text = str_replace('\U0001F490','\UE306',$text);
        $text = str_replace('\U0001F491','\UE425',$text);
        $text = str_replace('\U0001F492','\UE43D',$text);
        $text = str_replace('\U0001F51E','\UE207',$text);
        $text = str_replace('\U000000a9','\UE24E',$text);
        $text = str_replace('\U000000ae','\UE24F',$text);
        $text = str_replace('\U0002122','\UE537',$text);
        $text = str_replace('\U002320E3','\UE210',$text);
        $text = str_replace('\U003120E3','\UE21C',$text);
        $text = str_replace('\U003220e3','\UE21D',$text);
        $text = str_replace('\U003320E3','\UE21E',$text);
        $text = str_replace('\U003420E3','\UE21F',$text);
        $text = str_replace('\U003520E3','\UE220',$text);
        $text = str_replace('\U003620E3','\UE221',$text);
        $text = str_replace('\U003720E3','\UE222',$text);
        $text = str_replace('\U003820E3','\UE223',$text);
        $text = str_replace('\U003920E3','\UE224',$text);
        $text = str_replace('\U003020E3','\UE225',$text);
        $text = str_replace('\U0001F4F6','\UE20B',$text);
        $text = str_replace('\U0001F4F3','\UE250',$text);
        $text = str_replace('\U0001F4F4','\UE251',$text);
        $text = str_replace('\U0001F354','\UE120',$text);
        $text = str_replace('\U0001F359','\UE342',$text);
        $text = str_replace('\U0001F370','\UE046',$text);
        $text = str_replace('\U0001F35C','\UE340',$text);
        $text = str_replace('\U0001F35E','\UE339',$text);
        $text = str_replace('\U0001F373','\UE147',$text);
        $text = str_replace('\U0001F366','\UE33A',$text);
        $text = str_replace('\U0001F35F','\UE33B',$text);
        $text = str_replace('\U0001F361','\UE33C',$text);
        $text = str_replace('\U0001F358','\UE33D',$text);
        $text = str_replace('\U0001F35A','\UE33E',$text);
        $text = str_replace('\U0001F35D','\UE33F',$text);
        $text = str_replace('\U0001F35B','\UE341',$text);
        $text = str_replace('\U0001F362','\UE343',$text);
        $text = str_replace('\U0001F363','\UE344',$text);
        $text = str_replace('\U0001F371','\UE34C',$text);
        $text = str_replace('\U0001F372','\UE34D',$text);
        $text = str_replace('\U0001F367','\UE43F',$text);
        $text = str_replace('\U0001F374','\UE043',$text);
        $text = str_replace('\U0002615','\UE045',$text);
        $text = str_replace('\U0001F378','\UE044',$text);
        $text = str_replace('\U0001F37A','\UE047',$text);
        $text = str_replace('\U0001F375','\UE338',$text);
        $text = str_replace('\U0001F376','\UE30B',$text);
        $text = str_replace('\U0001F377','\UE044',$text);
        $text = str_replace('\U0001F37B','\UE30C',$text);
        $text = str_replace('\U0001F379','\UE044',$text);
        $text = str_replace('\U0002197','\UE236',$text);
        $text = str_replace('\U0002198','\UE238',$text);
        $text = str_replace('\U0002196','\UE237',$text);
        $text = str_replace('\U0002199','\UE239',$text);
        $text = str_replace('\U0002934','\UE236',$text);
        $text = str_replace('\U0002935','\UE238',$text);
        $text = str_replace('\U0002B06','\UE232',$text);
        $text = str_replace('\U0002B07','\UE233',$text);
        $text = str_replace('\U00027A1','\UE234',$text);
        $text = str_replace('\U0002B05','\UE235',$text);
        $text = str_replace('\U00025B6','\UE23A',$text);
        $text = str_replace('\U00025C0','\UE23B',$text);
        $text = str_replace('\U0002300','\UE23C',$text);
        $text = str_replace('\U00023EA','\UE23D',$text);
        $text = str_replace('\U0002B55','\UE332',$text);
        $text = str_replace('\U000274C','\UE333',$text);
        $text = str_replace('\U000274E','\UE333',$text);
        $text = str_replace('\U0002757','\UE021',$text);
        $text = str_replace('\U0002753','\UE020',$text);
        $text = str_replace('\U0002754','\UE336',$text);
        $text = str_replace('\U0002755','\UE337',$text);
        $text = str_replace('\U00027BF','\UE211',$text);
        $text = str_replace('\U0002764','\UE022',$text);
        $text = str_replace('\U0001F493','\UE327',$text);
        $text = str_replace('\U0001F494','\UE023',$text);
        $text = str_replace('\U0001F495','\UE327',$text);
        $text = str_replace('\U0001F496','\UE327',$text);
        $text = str_replace('\U0001F497','\UE328',$text);
        $text = str_replace('\U0001F498','\UE329',$text);
        $text = str_replace('\U0001F499','\UE32A',$text);
        $text = str_replace('\U0001F49A','\UE32B',$text);
        $text = str_replace('\U0001F49B','\UE32C',$text);
        $text = str_replace('\U0001F49C','\UE32D',$text);
        $text = str_replace('\U0001F49D','\UE437',$text);
        $text = str_replace('\U0001F49E','\UE327',$text);
        $text = str_replace('\U0001F49F','\UE204',$text);
        $text = str_replace('\U0002665','\UE20C',$text);
        $text = str_replace('\U0002660','\UE20E',$text);
        $text = str_replace('\U0002666','\UE20D',$text);
        $text = str_replace('\U0002663','\UE20F',$text);
        $text = str_replace('\U0001F6AC','\UE30E',$text);
        $text = str_replace('\U0001F6AD','\UE208',$text);
        $text = str_replace('\U000267F','\UE20A',$text);
        $text = str_replace('\U00026A0','\UE252',$text);
        $text = str_replace('\U00026D4','\UE137',$text);
        $text = str_replace('\U0001F6B2','\UE136',$text);
        $text = str_replace('\U0001F6B6','\UE201',$text);
        $text = str_replace('\U0001F6B9','\UE138',$text);
        $text = str_replace('\U0001F6BA','\UE139',$text);
        $text = str_replace('\U0001F6C0','\UE13F',$text);
        $text = str_replace('\U0001F6BB','\UE151',$text);
        $text = str_replace('\U0001F6BD','\UE140',$text);
        $text = str_replace('\U0001F6BE','\UE309',$text);
        $text = str_replace('\U0001F6BC','\UE13A',$text);
        $text = str_replace('\U0001F192','\UE214',$text);
        $text = str_replace('\U0001F194','\UE229',$text);
        $text = str_replace('\U0001F195','\UE212',$text);
        $text = str_replace('\U0001F197','\UE24D',$text);
        $text = str_replace('\U0001F199','\UE213',$text);
        $text = str_replace('\U0001F19A','\UE12E',$text);
        $text = str_replace('\U0001F201','\UE203',$text);
        $text = str_replace('\U0001F202','\UE228',$text);
        $text = str_replace('\U0001F233','\UE22B',$text);
        $text = str_replace('\U0001F235','\UE22A',$text);
        $text = str_replace('\U0001F236','\UE215',$text);
        $text = str_replace('\U0001F21A','\UE216',$text);
        $text = str_replace('\U0001F237','\UE217',$text);
        $text = str_replace('\U0001F238','\UE218',$text);
        $text = str_replace('\U0001F239','\UE227',$text);
        $text = str_replace('\U0001F22F','\UE22C',$text);
        $text = str_replace('\U0001F23A','\UE22D',$text);
        $text = str_replace('\U0003299','\UE315',$text);
        $text = str_replace('\U0003297','\UE30D',$text);
        $text = str_replace('\U0001F250','\UE226',$text);
        $text = str_replace('\U0002716','\UE333',$text);
        $text = str_replace('\U0001F4A1','\UE10F',$text);
        $text = str_replace('\U0001F4A2','\UE334',$text);
        $text = str_replace('\U0001F4A3','\UE311',$text);
        $text = str_replace('\U0001F4A4','\UE13C',$text);
        $text = str_replace('\U0001F4A6','\UE331',$text);
        $text = str_replace('\U0001F4A7','\UE331',$text);
        $text = str_replace('\U0001F4A8','\UE330',$text);
        $text = str_replace('\U0001F4A9','\UE05A',$text);
        $text = str_replace('\U0001F4AA','\UE14C',$text);
        $text = str_replace('\U0001F4AB','\UE407',$text);
        $text = str_replace('\U0002728','\UE32E',$text);
        $text = str_replace('\U0002734','\UE205',$text);
        $text = str_replace('\U0002733','\UE206',$text);
        $text = str_replace('\U00026AA','\UE219',$text);
        $text = str_replace('\U00026AB','\UE219',$text);
        $text = str_replace('\U0001F534','\UE219',$text);
        $text = str_replace('\U0001F535','\UE21A',$text);
        $text = str_replace('\U0001F532','\UE21A',$text);
        $text = str_replace('\U0001F533','\UE21B',$text);
        $text = str_replace('\U0002B50','\UE32F',$text);
        $text = str_replace('\U0002B1C','\UE21B',$text);
        $text = str_replace('\U0002B1B','\UE21A',$text);
        $text = str_replace('\U00025AB','\UE21B',$text);
        $text = str_replace('\U00025AA','\UE21A',$text);
        $text = str_replace('\U00025FD','\UE21B',$text);
        $text = str_replace('\U00025FE','\UE21A',$text);
        $text = str_replace('\U00025FB','\UE21B',$text);
        $text = str_replace('\U00025FC','\UE21A',$text);
        $text = str_replace('\U0001F536','\UE21B',$text);
        $text = str_replace('\U0001F537','\UE21B',$text);
        $text = str_replace('\U0001F538','\UE21B',$text);
        $text = str_replace('\U0001F539','\UE21B',$text);
        $text = str_replace('\U0002747','\UE32E',$text);
        $text = str_replace('\U0001F50A','\UE141',$text);
        $text = str_replace('\U0001F50D','\UE114',$text);
        $text = str_replace('\U0001F50E','\UE114',$text);
        $text = str_replace('\U0001F512','\UE144',$text);
        $text = str_replace('\U0001F513','\UE145',$text);
        $text = str_replace('\U0001F50F','\UE144',$text);
        $text = str_replace('\U0001F510','\UE144',$text);
        $text = str_replace('\U0001F511','\UE03F',$text);
        $text = str_replace('\U0001F514','\UE325',$text);
        $text = str_replace('\U0001F519','\UE235',$text);
        $text = str_replace('\U0001F51D','\UE24C',$text);
        $text = str_replace('\U000270A','\UE010',$text);
        $text = str_replace('\U000270B','\UE012',$text);
        $text = str_replace('\U000270C','\UE011',$text);
        $text = str_replace('\U0001F44A','\UE00D',$text);
        $text = str_replace('\U0001F44D','\UE00E',$text);
        $text = str_replace('\U000261D','\UE00F',$text);
        $text = str_replace('\U0001F446','\UE22E',$text);
        $text = str_replace('\U0001F447','\UE22F',$text);
        $text = str_replace('\U0001F448','\UE230',$text);
        $text = str_replace('\U0001F449','\UE231',$text);
        $text = str_replace('\U0001F44B','\UE41E',$text);
        $text = str_replace('\U0001F44F','\UE41F',$text);
        $text = str_replace('\U0001F44C','\UE420',$text);
        $text = str_replace('\U0001F44E','\UE421',$text);
        $text = str_replace('\U0001F450','\UE422',$text);

        $text = $this->filterEmoji($text);

        print_r($text);
        exit();
        preg_match('/var mv_hash = \/U([\s\S]*)\/A/',$text,$match);

        print_r($match);
        exit();
        echo preg_replace_callback(
            "/(?<=U)[0-9]+(?=A)/",
            function (array $match) {
                return strlen($match[0]) >= 4 ? $this->emmoji() : $match[0];
            },
            $text);
        exit();
        $text = $this->filterEmoji($text);
        print_r($text);
        exit();
        $text = str_replace('💔','[心碎]',$text);
        $text = str_replace('⚠️','\UE252',$text);
        $text = str_replace('🖐','\UE41E',$text);
        $text = str_replace('✨',$this->emmoji(),$text);


        print_r($text);
        exit();
        $this->mosheng();
        exit();

        $cosmos = new Cosmos();
        $data = $cosmos->where('images','>','')->limit(1)->order('createtime', 'desc')->select();
        $cosmos->where(['id'=>$data[0]->id])->setDec('createtime', 120);
        $data[0]->createtime = $data[0]->createtime - 500;
        $text = $data[0]->text;
        $images = '';
        if (!empty($data[0]->images)){
            foreach (explode(',', $data[0]->images) as $value ){
                $images = "[结束][img]".$value."[/img]";
            }
        }
        echo '{"rs":1,"wxid":"13680952411@chatroom","tip":"'.$text.$images.'","end":1}';
        exit();


        $time = time();
        echo '{"rs":1,"wxid":"13680952411@chatroom","tip":"定时消息的内容","end":1}';

        exit();
        $this->mosheng();
        sleep(30);
        $this->mosheng();

        exit();
        $params = $data;
        $method = 'POST';
        $protocol = substr($url, 0, 5);
        $query_string = is_array($params) ? http_build_query($params) : $params;

        $ch = curl_init();
        $defaults = [];
        $defaults[CURLOPT_URL] = $url;
        if ($method == 'POST') {
            $defaults[CURLOPT_POST] = 1;
        } else {
            $defaults[CURLOPT_CUSTOMREQUEST] = 'POST';
        }
//        $defaults[CURLOPT_POSTFIELDS] = $params;

//        $defaults[CURLOPT_HEADER] = false;
        $defaults[CURLOPT_USERAGENT] = "mosheng.weiling (Android; OS/28; zh-cn; Branchs HUAWEI:HLKAL10) Version/4.6.8 Device/1080x2340 Ca/90017";
//        $defaults[CURLOPT_FOLLOWLOCATION] = true;
//        $defaults[CURLOPT_RETURNTRANSFER] = true;
//        $defaults[CURLOPT_CONNECTTIMEOUT] = 3;
//        $defaults[CURLOPT_TIMEOUT] = 3;
        curl_setopt($ch, CURLOPT_HTTPHEADER, $options);

        if ('https' == $protocol) {
            $defaults[CURLOPT_SSL_VERIFYPEER] = false;
            $defaults[CURLOPT_SSL_VERIFYHOST] = false;
        }
//        print_r(k);
//        exit();

        curl_setopt_array($ch, $defaults);

        $ret = curl_exec($ch);
        $err = curl_error($ch);

        print_r($ret);

        exit();

//        User-Agent	mosheng.weiling (Android; OS/28; zh-cn; Branchs HUAWEI:HLKAL10) Version/4.6.8 Device/1080x2340 Ca/90017
//X-API-UA	mosheng.weiling (Android; OS/28; zh-cn; Branchs HUAWEI:HLKAL10) Version/4.6.8 Device/1080x2340 Ca/90017
//X-API-USERID	16990061928974
//X-API-TOKEN	fdc81c0aeae06d52bbc8d353cb742b33
//Content-Type	application/x-www-form-urlencoded
//        $imagess = 'dawdaw,awdawd,dddd,dddd';
//        $images = '';
//        foreach (explode(',', $imagess) as $value ){
//            $images = $images ."[结束][img]".$value."[/img]";
//        }
//
//        exit($images);
//       $model = new Append();
//       $test =  $model->where(['user_id'=>1])->select();
//       print_r($test);
//       exit();

//        $url = 'http://qun.wqchat.com/index.php?m=wingpcnew&a=api_getgroupinfo&vol=Dev3.26';
        $url='http://www.shanliulian.com/app/index.php?m=wingapp&a=app_replytime';

        $data = [
            'u'=>'126748','wxuin'=>'wxid_cxrh6lfe9hvm12','wxuin_admin'=>'wxid_2hpiqb83a9hp22','nickname'=>'','roomid'=>'13680952411@chatroom','gname'=>'','appopen'=>'on','vol'=>'Dev3.2'
        ];
        $test = Http::post($url,$data);
        print_r($test);
        exit();

//        POST /index.php?m=wingpcnew&a=api_getgroupinfo&vol=Dev3.26 HTTP/1.1
//Accept: */*
//Referer: http://qun.wqchat.com/index.php?m=wingpcnew&a=api_getgroupinfo&vol=Dev3.26
//Accept-Language: zh-cn
//Content-Type: application/x-www-form-urlencoded
//User-Agent: Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)
//Host: qun.wqchat.com
//Content-Length: 134
//Cache-Control: no-cache
//Cookie: think_language=zh-cn; PHPSESSID=fhuvvfh49dg4870uefoov580c2
//
//u=126748&wxuin=wxid_cxrh6lfe9hvm12&wxuin_admin=wxid_2hpiqb83a9hp22&nickname=&roomid=13680952411@chatroom&gname=&appopen=on&vol=Dev3.26


//        Http::post(,'u=126748&gid=461353&gusername=13680952411@chatroom&gname=&robotid=wxid_cxrh6lfe9hvm12&skw=4173');
//        POST http://www.shanliulian.com/app/index.php?m=wingapp&a=app_replytimeHTTP/1.1
//Accept: */*
//Referer: http://www.shanliulian.com/app/index.php?m=wingapp&a=app_replytime
//Accept-Language: zh-cn
//Content-Type: application/x-www-form-urlencoded
//User-Agent: Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)
//Host: www.shanliulian.com
//Content-Length: 94
//Cache-Control: no-cache
//Cookie: think_language=zh-cn; PHPSESSID=559a161b7c17687ef3bd59fbff3924d8
//
//u=126748&gid=461353&gusername=13680952411@chatroom&gname=&robotid=wxid_cxrh6lfe9hvm12&skw=4173
//

//        \think\Console::addDefaultCommands([
//
//            'addons\moyicosmic\library\GatewayWorker\start'
//
//        ]);
//        $text = '我踏马看总裁文看上头了\U0002F123\U0002F123';
////        substr($text,-0,);
//        print_r(        preg_match_all();
//    );

//        preg_match_all("|<[^>]+>(.*)</[^>]+>|U", $text, $matches);

//preg_replace($pattern, $newChar, $str)


    }
    // 数据采集示范
    public function collect()
    {

        $url = 'http://api.cdadkj.com:84/webbsservice/was?appKey=sn113170a1ba8245aeb279dbd3f6887a5c&bbs_id=&method=bbs.post.list.new&topic_id=0&v=2.0&fm=json&sign=1B004167D7EA242D3D24E8D10861AE4220B4B491&sessionid=9af06515e545734d5c75f8fe5cd85ae1';
        $data = Http::get($url);
        $data = json_decode($data);
        $i = 0;
        $collect_i = 0;
        foreach (array_reverse($data->data) as $res) {
            $i ++ ;
            $user_id = Common::createUser([
                'username' => 'love_' . $res->uid,
                'nickname' => $res->user->nickname,
                'avatar' => $res->user->headimgurl,
                'gender' => $res->user->sex != 1 ? 0 : 1
            ]);
            if (!Cosmos::get(['third_id' => $res->bbs_id, 'collect' => 1])) {
                $images = '';
                if (!empty($res->images)){
                    foreach ($res->images as $ress){
                        if (empty($images)){
                            $images = $ress->original_pic;
                        }else{
                            $images = $images.','.$ress->original_pic;
                        }
                    }
                }
                Cosmos::create([
                    'user_id' => $user_id,
                    'text' => $res->text,
                    'third_id' => $res->bbs_id,
                    'collect' => 1,
                    'place'=>$res->city,
                    'images'=>$images,
                    'likes'=>$res->likes_count,
                    'createtime'=>$res->created_at / 1000
                ]);
                $collect_i ++;
            }
        }

        $res = [
            'platform'=>'恋爱物语',
            'count'=>$i,
            'collect'=>$collect_i,
            'time'=>date("Y-m-d H:i:s",intval(time()))];
        if($i){
            if (get_addon_config('vbot')) {
                $vbot = new \addons\vbot\Vbot();
                $vbot->vbotSendMsg('collect_notice', [], $res);
            }
        }else{
            if (get_addon_config('vbot')) {
                $vbot = new \addons\vbot\Vbot();
                $vbot->vbotSendMsg('collect_error', [], ['content'=>$data]);
            }
        }
        $this->error('ok');
    }
}
