<?php

namespace app\api\controller\moyicosmic;

use app\common\library\Sms as Smslib;
use app\common\model\User;
use app\common\model\Sms as SmsModel;
use think\Exception;

/**
 * 手机短信接口
 */
class Sms extends Base
{
    protected $noNeedLogin = '*';
    protected $noNeedRight = '*';

    protected $errMsg = 'Incorrect mobile phones';

    function safetyCheck($mobile, $event)
    {
        try {
            // 是否有手机号码
            if (!$mobile) {
                return false;
            };
            // 检查操作时间
            $last = Smslib::get($mobile, $event);
            if ($last && time() - $last['createtime'] < 60) {
                $this->errMsg = 'Frequent operation';
                return false;
            };
            // 检查操作IP
            $ipSendTotal = (new SmsModel)->where(['ip' => $this->request->ip()])->whereTime('createtime',
                '-1 hours')->count();
            if ($ipSendTotal >= 5) {
                $this->errMsg = 'Frequent operation';
                return false;
            }
            return true;
        } catch (Exception $e) {
            $this->errMsg = 'An error occurred';
            return false;
        }
    }

    /**
     * 发送登陆验证码
     * @param string $mobile 手机号
     */
    public function sendLoginCaptcha()
    {
        $mobile = $this->request->post("mobile");
        $event = ' ';
        if ($this->safetyCheck($mobile,$event)){
            $userInfo = User::getByMobile($mobile);
            if (!$userInfo){
                $this->error(__('unregistered'));
            }else{
                $ret = Smslib::send($mobile, null, $event);
                if ($ret) {
                    $this->success(__('Send successfully'));
                } else {
                    $this->error(__('Send failure'));
                }
            }
        }else{
            $this->error(__($this->errMsg));
        }
    }

    /**
     * 发送绑定验证码
     * @param string $mobile 手机号
     */
    public function sendBindMobile()
    {
        $mobile = $this->request->post("newMobile");
        $event = 'bindMobile';
        try{
            if ($this->safetyCheck($mobile,$event)){
                $ret = Smslib::send($mobile, null, $event);
                if ($ret) {
                    $this->success(__('发送成功'));
                } else {
                    $this->error(__('发送失败'));
                }
            }else{
                $this->error(__($this->errMsg));
            }
        }catch (Exception $exception){
            $this->error(__('未绑定手机号码'));
        }
    }

}
