<?php

return [
    'Id'            => 'ID',
    'Type'          => '第三方登录类型',
    'User_id'       => '会员ID',
    'Openid'        => '第三方唯一ID',
    'Unionid'       => '第三方唯一UNID',
    'Access_token'  => 'AccessToken',
    'Session_key'   => 'Session_key',
    'Nickname'      => '昵称',
    'Avatar'        => '头像',
    'Gender'        => '性别 0：未知、1：男、2：女',
    'Language'      => '语言',
    'City'          => '城市',
    'Province'      => '省',
    'Country'       => '国家',
    'Country_code'  => '手机号码国家编码',
    'Mobile'        => '手机号码',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Deletetime'    => '删除时间',
    'User.nickname' => '昵称',
    'User.avatar'   => '头像'
];
