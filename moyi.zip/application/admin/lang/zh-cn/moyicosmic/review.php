<?php

return [
    'Id'                => 'ID',
    'Pid'               => '父ID',
    'User_id'           => '用户ID',
    'Reply_id'          => '回复ID',
    'Reply_user_id'     => '回复用户ID',
    'Text'              => '文字内容',
    'Createtime'        => '创建时间',
    'Updatetime'        => '更新时间',
    'Deletetime'        => '删除时间',
    'Status'            => '状态',
    'moyicosmiccosmos.text' => '文字内容',
    'User.nickname'     => '昵称',
    'User.avatar'       => '头像'
];
