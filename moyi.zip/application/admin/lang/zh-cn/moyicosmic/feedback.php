<?php

return [
    'Id'            => 'ID',
    'User_id'       => '用户ID',
    'Text'          => '文字内容',
    'Contact'       => '联系方式',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Deletetime'    => '删除时间',
    'Status'        => '状态',
    'User.nickname' => '昵称',
    'User.avatar'   => '头像'
];
