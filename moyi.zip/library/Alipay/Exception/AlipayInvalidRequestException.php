<?php

namespace addons\moyicosmic\library\Alipay\Exception;

/**
 * 在请求类工厂内，当试图使用无效的参数创建请求类时抛出。
 */
class AlipayInvalidRequestException extends AlipayException
{
}
