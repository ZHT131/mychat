<?php

namespace addons\moyicosmic;

use app\common\library\Menu;
use think\Addons;
use think\Db;

/**
 * 插件
 */
class moyicosmic extends Addons
{

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        return true;
    }
    /**
     * 增加命令
     */
    public function appInit($param)
    {
        if (request()->isCli()) {
            \think\Console::addDefaultCommands([
                'addons\moyicosmic\library\GatewayWorker\start'

            ]);
        }
    }

}
