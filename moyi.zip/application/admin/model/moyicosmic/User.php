<?php

namespace app\admin\model\moyicosmic;

use think\Model;

/**
 * Class User
 * @package app\admin\model\moyicosmic
 */
class User extends Model
{
    // 表名
    protected $name = 'user';

}
