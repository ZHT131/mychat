<?php

return [
    'Id'                      => 'ID',
    'Pid'                     => '父ID',
    'User_id'                 => '用户ID',
    'Createtime'              => '创建时间',
    'Updatetime'              => '更新时间',
    'Deletetime'              => '删除时间',
    'Status'                  => '状态',
    'moyicosmiccosmos.id'         => 'ID',
    'moyicosmiccosmos.user_id'    => '用户ID',
    'moyicosmiccosmos.flag'       => '标志组',
    'moyicosmiccosmos.secret'     => '隐私',
    'moyicosmiccosmos.place'      => '地点',
    'moyicosmiccosmos.views'      => '浏览',
    'moyicosmiccosmos.likes'      => '喜欢',
    'moyicosmiccosmos.reviews'    => '评论',
    'moyicosmiccosmos.shares'     => '分享',
    'moyicosmiccosmos.text'       => '文字内容',
    'moyicosmiccosmos.images'     => '相册组',
    'moyicosmiccosmos.weigh'      => '权重',
    'moyicosmiccosmos.collect'    => '采集,0：正常、1：采集1号平台',
    'moyicosmiccosmos.third_id'   => '防止重复采集第三方ID',
    'moyicosmiccosmos.createtime' => '创建时间',
    'moyicosmiccosmos.updatetime' => '删除时间',
    'moyicosmiccosmos.deletetime' => '删除时间',
    'moyicosmiccosmos.status'     => '状态'
];
