<?php

namespace app\admin\model\moyicosmic;

use think\Model;
use traits\model\SoftDelete;

class Friend extends Model
{

    use SoftDelete;

    

    // 表名
    protected $name = 'moyicosmic_friend';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = false;
    protected $deleteTime = 'deletetime';

    // 追加属性
    protected $append = [

    ];

    public function user()
    {
        return $this->hasOne('app\admin\model\moyicosmic\User', 'id', 'friend_id', [], 'LEFT')->setEagerlyType(0);
    }
}
