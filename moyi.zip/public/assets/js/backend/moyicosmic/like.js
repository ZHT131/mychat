define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'moyicosmic/like/index' + location.search,
                    add_url: 'moyicosmic/like/add',
                    edit_url: 'moyicosmic/like/edit',
                    del_url: 'moyicosmic/like/del',
                    multi_url: 'moyicosmic/like/multi',
                    table: 'moyicosmic_like',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'pid', title: __('Pid')},
                        {field: 'user_id', title: __('User_id')},
                        {field: 'createtime', title: __('Createtime'), operate:'RANGE', addclass:'datetimerange', formatter: Table.api.formatter.datetime},
                        {field: 'updatetime', title: __('Updatetime'), operate:'RANGE', addclass:'datetimerange', formatter: Table.api.formatter.datetime},
                        {field: 'status', title: __('Status'), searchList: {"normal":__('Normal'),"hidden":__('Hidden')}, formatter: Table.api.formatter.status},
                        {field: 'moyicosmiccosmos.id', title: __('moyicosmiccosmos.id')},
                        {field: 'moyicosmiccosmos.user_id', title: __('moyicosmiccosmos.user_id')},
                        {field: 'moyicosmiccosmos.flag', title: __('moyicosmiccosmos.flag'), formatter: Table.api.formatter.flag},
                        {field: 'moyicosmiccosmos.secret', title: __('moyicosmiccosmos.secret')},
                        {field: 'moyicosmiccosmos.place', title: __('moyicosmiccosmos.place')},
                        {field: 'moyicosmiccosmos.views', title: __('moyicosmiccosmos.views')},
                        {field: 'moyicosmiccosmos.likes', title: __('moyicosmiccosmos.likes')},
                        {field: 'moyicosmiccosmos.reviews', title: __('moyicosmiccosmos.reviews')},
                        {field: 'moyicosmiccosmos.shares', title: __('moyicosmiccosmos.shares')},
                        {field: 'moyicosmiccosmos.text', title: __('moyicosmiccosmos.text')},
                        {field: 'moyicosmiccosmos.images', title: __('moyicosmiccosmos.images'), events: Table.api.events.image, formatter: Table.api.formatter.images},
                        {field: 'moyicosmiccosmos.weigh', title: __('moyicosmiccosmos.weigh')},
                        {field: 'moyicosmiccosmos.collect', title: __('moyicosmiccosmos.collect')},
                        {field: 'moyicosmiccosmos.third_id', title: __('moyicosmiccosmos.third_id')},
                        {field: 'moyicosmiccosmos.createtime', title: __('moyicosmiccosmos.createtime'), operate:'RANGE', addclass:'datetimerange', formatter: Table.api.formatter.datetime},
                        {field: 'moyicosmiccosmos.updatetime', title: __('moyicosmiccosmos.updatetime'), operate:'RANGE', addclass:'datetimerange', formatter: Table.api.formatter.datetime},
                        {field: 'moyicosmiccosmos.deletetime', title: __('moyicosmiccosmos.deletetime'), operate:'RANGE', addclass:'datetimerange', formatter: Table.api.formatter.datetime},
                        {field: 'moyicosmiccosmos.status', title: __('moyicosmiccosmos.status'), formatter: Table.api.formatter.status},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        recyclebin: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    'dragsort_url': ''
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: 'moyicosmic/like/recyclebin' + location.search,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {
                            field: 'deletetime',
                            title: __('Deletetime'),
                            operate: 'RANGE',
                            addclass: 'datetimerange',
                            formatter: Table.api.formatter.datetime
                        },
                        {
                            field: 'operate',
                            width: '130px',
                            title: __('Operate'),
                            table: table,
                            events: Table.api.events.operate,
                            buttons: [
                                {
                                    name: 'Restore',
                                    text: __('Restore'),
                                    classname: 'btn btn-xs btn-info btn-ajax btn-restoreit',
                                    icon: 'fa fa-rotate-left',
                                    url: 'moyicosmic/like/restore',
                                    refresh: true
                                },
                                {
                                    name: 'Destroy',
                                    text: __('Destroy'),
                                    classname: 'btn btn-xs btn-danger btn-ajax btn-destroyit',
                                    icon: 'fa fa-times',
                                    url: 'moyicosmic/like/destroy',
                                    refresh: true
                                }
                            ],
                            formatter: Table.api.formatter.operate
                        }
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});