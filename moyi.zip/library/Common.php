<?php
// +----------------------------------------------------------------------
// | FileName: Moyigateway.php
// +----------------------------------------------------------------------
// | Date: 2019-12-23 
// +----------------------------------------------------------------------
// | Source:  ( https://www.fastadmin.net/store/moyi.html )
// +----------------------------------------------------------------------
// | Author: 默毅 <moyi@mymoyi.cn> 、白衣素袖
// +----------------------------------------------------------------------
namespace addons\moyicosmic\library;

use addons\moyicosmic\library\AlipayHelper;
use app\admin\model\moyicosmic\Subscribe;
use app\admin\model\moyicosmic\Subscribelog;
use app\admin\model\moyicosmic\Third;
use app\admin\model\User;
use app\admin\model\moyicosmic\Append;
use CURLFile;
use fast\Random;
use think\Exception;
use think\exception\DbException;

class Common
{
    /**
     * 获取用户信息
     * @param $user_id
     * @param bool $all
     * @return array
     */
    public static function getUserInfo($user_id, $all = false)
    {
        try {
            $user = User::get($user_id);
            if ($user) {
                $user->visible(['id', 'username', 'nickname', 'avatar', 'gender', 'bio']);
                $append = Append::get($user_id);
                if (!$append) {
                    $append = Append::create(['user_id' => $user_id]);
                }
                if (!$all) {
                    $append->visible(['image', 'vip', 'frame', 'views', 'country', 'place']);
                }
                if ($append) {
                    return array_merge($user->toArray(), $append->toArray());
                }
            }
            return [];
        } catch (DbException $e) {
            return [];
        } catch (Exception $e) {
            return [];
        }
    }

    /**
     * 创建新用户
     * @param  $arr    array
     * @return object|boolean
     * @throws DbException
     */
    public static function createUser($arr)
    {
        if (!empty($arr['username'])) {
            $user = User::get(['username' => $arr['username']]);
            if ($user) {
                return empty($user->id) ? 0 : $user->id;
            }
        }
        $time = time();
        $ip = request()->ip();
        $params = [
            'username' => '@null' . Random::alnum(8) . $time,
            'nickname' => '新用户' . Random::alnum(5),
            'joinip' => $ip,
            'loginip' => $ip,
            'status' => 'normal',
        ];
        $params = array_merge($params, $arr);
        $user = new User($params);
        $user->allowField(true)->save();
        return $user['id'];
    }


    /**
     * 实时文本内容审查
     * @param $val string
     * @return bool|string
     */
    public static function auditText($val)
    {
        $config = get_addon_config('moyicosmic');
        if ($config['aliyun_audit'] == 0 || empty($val)) {
            return true;
        }
        $biz = empty($conf['aliyun_audit_biz']);
        $temp = AlipayHelper::checkText($val);
        if ($biz) {
            $label = empty($temp->label) ? 'error' : $temp->label;
            if (in_array($label, explode(',', $config['aliyun_audit_list']))) {
                // 命中文本审核规则
                return false;
            }
        } else {
            $suggestion = empty($temp->suggestion) ? 'review' : $temp->suggestion;
            if ($suggestion != 'pass') {
                // 命中图片审核规则
                return $suggestion;
            }
        }
        return true;
    }

    /**
     * @param $uid integer      用户ID
     * @param $template string  模版代码
     * @param $data array       发送数据
     * @param string $page string      卡片进入页面
     * @return bool|mixed|string
     */
    public static function subscribeMessageSend($uid, $template, $data,$page = '')
    {
        try {
            $uid = Third::get(['user_id' => $uid, 'type' => 'wechat']);
            if (!$uid) {
                // 未找到用户
                return false;
            }
            $Subscribe = Subscribe::get(['code' => $template, 'type' => 'wechat']);
            if (!$Subscribe) {
                // 未找到订阅模版
                return false;
            }
            $p = array();
            foreach (json_decode(empty($Subscribe->params) ? '' : $Subscribe->params) as $item => $value) {
                $p = empty($data[$item]) ? array_merge($p, array(
                    $value => array(
                        'value' => $item == 'time' ? date('Y年m月d日 h:i', time()) : '未设置字段'
                    )
                )) : array_merge($p, array($value => array('value' => $data[$item])));
            }
            $params = array(
                'touser' => $uid['openid'],
                'template_id' => $Subscribe['template'],
                'page' => $page?$page:$Subscribe['page'],
                'miniprogram_state' => $Subscribe['miniprogram_state'],
                'data' => $p
            );
            $wechat = new WechatHelper();
            $re = $wechat->subscribeMessageSend($params);
            Subscribelog::create([
                'type' => 'wechat',
                'code' => $wechat->getErrorCode(),
                'msg' => $wechat->getErrorMsg(),
                'params' => json_encode($params),
                'template' => $template,
                'status' => $re ? 'success' : 'error'
            ]);
            return $re;
        } catch (DbException $e) {
            return false;
        }
    }
//subscribeMessageSend

    /**
     * 实时图片内容审查
     * @param $images array|string
     * @return bool|string
     */
    public static function auditImages($images)
    {
        $config = get_addon_config('moyicosmic');
        if ($config['aliyun_audit'] == 0 || empty($config['aliyun_audit_image_scenes']) || empty($images)) {
            return true;
        }

        $temp = AlipayHelper::checkImage(is_array($images) ? $images : explode(',', $images));

        $biz = empty($conf['aliyun_audit_biz']);

        // 传图错误；
        if (empty($temp)) {
            if (in_array('error', explode(',', $config['aliyun_audit_image_list']))) {
                return false;
            }
        }
        foreach ($temp as $values) {
            foreach ($values as $value) {
                if ($biz) {
                    $label = empty($value->label) ? 'error' : $value->label;
                    if (in_array($label, explode(',', $config['aliyun_audit_image_list']))) {
                        // 命中图片审核规则
                        return false;
                    }
                } else {
                    $suggestion = empty($value->suggestion) ? 'review' : $value->suggestion;
                    if ($suggestion != 'pass') {
                        // 命中图片审核规则
                        return $suggestion;
                    }
                }
            }
        }
        return true;
    }

    /**
     * 自己给自己接口模拟自给自己上传，哈哈虽然我在套娃娃，但能不重写解决需求
     * 网络保存图片(23秒保存失败则返回false)
     * @param $img //网路图片路径
     * @param $token //用户的token
     * @param string $domain //默认网址路径
     * @return bool|string
     */
    public static function imageSave($img = '', $token = '', $domain = 'http://localhost')
    {
        $upload_url = $domain . '/api/moyicosmic/common/upload';
        // 临时保存文件
        $file_name = Random::alnum(12) . '.jpg';
        $img = file_get_contents($img);
        file_put_contents('uploads/' . $file_name, $img);
        $ch = curl_init($upload_url);
        $file = ROOT_PATH . 'public' . DS . 'uploads' . DS . $file_name;
        //检测请求版本
        if (class_exists('\CURLFile')) {
            curl_setopt($ch, CURLOPT_SAFE_UPLOAD, true);
            $data = array('file' => new CURLFile($file)); //>=5.5
        } else {
            if (defined('CURLOPT_SAFE_UPLOAD')) {
                curl_setopt($ch, CURLOPT_SAFE_UPLOAD, false);
            }
            $data = array('file' => '@' . $file); //<=5.5
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['token:' . $token]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 3);
        @$result = curl_exec($ch);
        @file_exists($file) && @unlink($file);
        $result = json_decode($result);
        if (!empty($result->code) && $result->code) {
            if (cdnurl('') == '') {
                return $domain . $result->data->url;
            } else {
                return cdnurl($result->data->url);
            }
        }
        return false;
    }

    /**
     * 取汉字的第一个字的首字母
     * @param string $str
     * @return string|null
     */
    public static function getFirstChar($str)
    {
        if (empty($str)) {
            return '';
        }

        $fir = $fchar = ord($str[0]);
        if ($fchar >= ord('A') && $fchar <= ord('z')) {
            return strtoupper($str[0]);
        }
        $s1 = @iconv('UTF-8', 'gb2312//IGNORE', $str);
        $s2 = @iconv('gb2312', 'UTF-8', $s1);
        $s = $s2 == $str ? $s1 : $str;
        if (!isset($s[0]) || !isset($s[1])) {
            return '';
        }

        $asc = ord($s[0]) * 256 + ord($s[1]) - 65536;

        if (is_numeric($str)) {
            return $str;
        }

        if (($asc >= -20319 && $asc <= -20284) || $fir == 'A') {
            return 'A';
        }
        if (($asc >= -20283 && $asc <= -19776) || $fir == 'B') {
            return 'B';
        }
        if (($asc >= -19775 && $asc <= -19219) || $fir == 'C') {
            return 'C';
        }
        if (($asc >= -19218 && $asc <= -18711) || $fir == 'D') {
            return 'D';
        }
        if (($asc >= -18710 && $asc <= -18527) || $fir == 'E') {
            return 'E';
        }
        if (($asc >= -18526 && $asc <= -18240) || $fir == 'F') {
            return 'F';
        }
        if (($asc >= -18239 && $asc <= -17923) || $fir == 'G') {
            return 'G';
        }
        if (($asc >= -17922 && $asc <= -17418) || $fir == 'H') {
            return 'H';
        }
        if (($asc >= -17417 && $asc <= -16475) || $fir == 'J') {
            return 'J';
        }
        if (($asc >= -16474 && $asc <= -16213) || $fir == 'K') {
            return 'K';
        }
        if (($asc >= -16212 && $asc <= -15641) || $fir == 'L') {
            return 'L';
        }
        if (($asc >= -15640 && $asc <= -15166) || $fir == 'M') {
            return 'M';
        }
        if (($asc >= -15165 && $asc <= -14923) || $fir == 'N') {
            return 'N';
        }
        if (($asc >= -14922 && $asc <= -14915) || $fir == 'O') {
            return 'O';
        }
        if (($asc >= -14914 && $asc <= -14631) || $fir == 'P') {
            return 'P';
        }
        if (($asc >= -14630 && $asc <= -14150) || $fir == 'Q') {
            return 'Q';
        }
        if (($asc >= -14149 && $asc <= -14091) || $fir == 'R') {
            return 'R';
        }
        if (($asc >= -14090 && $asc <= -13319) || $fir == 'S') {
            return 'S';
        }
        if (($asc >= -13318 && $asc <= -12839) || $fir == 'T') {
            return 'T';
        }
        if (($asc >= -12838 && $asc <= -12557) || $fir == 'W') {
            return 'W';
        }
        if (($asc >= -12556 && $asc <= -11848) || $fir == 'X') {
            return 'X';
        }
        if (($asc >= -11847 && $asc <= -11056) || $fir == 'Y') {
            return 'Y';
        }
        if (($asc >= -11055 && $asc <= -10247) || $fir == 'Z') {
            return 'Z';
        }

        return '';
    }

}