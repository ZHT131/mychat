<?php
// +----------------------------------------------------------------------
// | FileName: Cms.php
// +----------------------------------------------------------------------
// | Date: 2020-03-16 
// +----------------------------------------------------------------------
// | Source:  ( https://www.fastadmin.net/store/moyi.html )
// +----------------------------------------------------------------------
// | Author: 默毅 <moyi@mymoyi.cn>
// +----------------------------------------------------------------------


namespace app\api\controller\moyicosmic;

use think\Exception;
use app\admin\model\moyicosmic\Cms as CmsMobile;

class Cms extends Base
{

    protected $noNeedLogin = [
        'getDetails'
    ];
    /**
     *
     * @throws \think\exception\DbException
     */
    public function getDetails()
    {
        $id = $this->request->post('id');
        $data = CmsMobile::get($id);
        if ($data) {
            $this->success('', $data);
        } else {
            $this->error(__(''));
        }
    }
}