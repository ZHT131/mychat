<?php

return [
    'User_id'    => '客户端返回的时间ID',
    'Images'     => '相册组',
    'Text'       => '类型',
    'Vip'        => 'vip登记',
    'Bill'       => '消费金额',
    'Invite'     => '邀请人数',
    'Energy'     => '能量',
    'Frame'      => '头像框',
    'Frames'     => '头像框合集',
    'Views'      => '浏览',
    'Likes'      => '喜欢',
    'Reviews'    => '评论',
    'Country'    => '国家/地区',
    'Place'      => '地区',
    'Part'       => '地点',
    'Createtime' => '创建时间',
    'Deletetime' => '删除时间'
];
