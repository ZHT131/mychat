<?php
// +----------------------------------------------------------------------
// | FileName: Moyigateway.php
// +----------------------------------------------------------------------
// | Date: 2019-12-23 
// +----------------------------------------------------------------------
// | Source:  ( https://www.fastadmin.net/store/moyi.html )
// +----------------------------------------------------------------------
// | Author: 默毅 <moyi@mymoyi.cn> 、白衣素袖
// +----------------------------------------------------------------------
namespace addons\moyicosmic\library;

use think\Config;
use think\Db;
use think\Exception;
use think\exception\DbException;
use think\exception\PDOException;

class Moyigateway
{
    /**
     * 当客户端连接时触发
     * 如果业务不需此回调可以删除onConnect
     *
     * @param int $client_id 连接id
     * @return string
     * @throws Exception
     */

    public static function connect($client_id){
//        $arr = User::get($client_id)->toArray();
//        return self::success('服务器连接成功',[],'init');
    }

    public static function notPushMsg($user_id){
        $list = [];
        try {
            $list = Db::name('moyicosmic_record')->where(['to'=>$user_id,'status'=>0])->select();
            Db::name('moyicosmic_record')->where(['to' => $user_id, 'status' => 0])->update(['status' => 1]);
        } catch (PDOException $e) {
        } catch (Exception $e) {
        }
        print_r($list);
        echo 'notPushMsg离线发送消息';
//        print_r($list);
        return $list;


    }
    /**
     * @param $client_id
     * @return string
     */
    public static function message($client_id,$msg){
        return self::success('收到消息',$msg);
    }
    /**
     * 获取用户讯息
     * @param $user_id
     * @return array
     * @throws Exception
     * @throws DbException
     */
    public static function getUserInfo($user_id){

        return  Db::name('user')->where(['id'=>$user_id])->column('id,nickname,avatar,bio,score,birthday,level,gender');
    }


    /**
     * @param string $msg
     * @param array $data
     * @param string $type
     * @return string
     */
    public static function success($msg='',$data=[],$type='msg'){
        echo  'success'.$type;
        return json_encode(['code'=>1,'msg'=>$msg,'data'=>$data,'type'=>$type,'time'=>time()]);
    }
    /**
     * 失败或更多
     * @param string $msg
     * @param array $data
     * @param string $type
     * @param int $code
     * @return string
     */
    public static function error($msg='',$data=[],$type='msg',$code = 0){
        return json_encode(['code'=>$code,'msg'=>$msg,'data'=>$data,'type'=>$type,'time'=>time()]);
    }


    /**
     * 检查朋友关系
     * @param $user_id
     * @param $friend_id
     * @return bool
     * @throws Exception
     */
    public static function checkFriend($user_id,$friend_id)
    {
        return Db::name('moyicosmic_friend')->where(['user_id'=>$user_id,'friend_id'=>$friend_id,'state'=>'normal'])->count();
    }


    /**
     * 检查token
     * @param string token 用户的token信息
     * @param string user_id 用户的id信息
     * @return boolean
     * @throws Exception
     */
    public static function checkToken($token,$user_id)
    {
        if (Db::name('user_token')->where('token', Moyigateway::getEncryptedToken($token))->where('user_id',$user_id)->count()){
            return true;
        }
        return false;
    }

    /**
     * 用户token加密
     * @param string $token 待加密的token
     * @return string
     */
    public static function getEncryptedToken($token)
    {
        $token_config = Config::get('token');
        $config = array(
            // 缓存前缀
            'key'      => $token_config['key'],
            // 加密方式
            'hashalgo' => $token_config['hashalgo'],
        );
        return hash_hmac($config['hashalgo'], $token, $config['key']);
    }


    /**
     * 保存聊天记录
     * @param $data
     * @param $status
     */
    public static function saveRecord($data,$status){
        $arr = [
            'to'=>$data->to,
            'from'=>$data->from,
            'value'=>$data->value,
            'status'=>$status,
            'time'=>$data->time,
        ];
        Db::name('moyicosmic_record')->insert($arr);
//        Db::name('moyicosmic_record')
    }

}