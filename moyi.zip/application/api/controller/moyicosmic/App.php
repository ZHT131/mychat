<?php
// +----------------------------------------------------------------------
// | FileName: Cms.php
// +----------------------------------------------------------------------
// | Date: 2020-03-16 
// +----------------------------------------------------------------------
// | Source:  ( https://www.fastadmin.net/store/moyi.html )
// +----------------------------------------------------------------------
// | Author: 默毅 <moyi@mymoyi.cn>
// +----------------------------------------------------------------------


namespace app\api\controller\moyicosmic;

use app\admin\model\moyicosmic\Subscribe;
use think\Exception;
use app\admin\model\moyicosmic\Cms as CmsMobile;

class App extends Base
{

    protected $noNeedLogin = [
        'init'
    ];
    /**
     *
     * @throws \think\exception\DbException
     */
    public function init()
    {
        $config=get_addon_config('moyicosmic');
        $db = [];
        foreach ($config['init_db'] as $key => $value){
            $db[] = ['key'=>$key,'value'=>$value];
        }
        $subscribe = Subscribe::all(['type'=>'wechat']);
        foreach ($subscribe as  $value){
            $db[] = ['key'=>'subscribe_'.$value['code'],'value'=>$value['template']];
        }
        $this->success('test',['db'=>$db]);
    }
}