<?php
// +----------------------------------------------------------------------
// | FileName: TencentHelper.php
// +----------------------------------------------------------------------
// | Date: 2019-12-10
// +----------------------------------------------------------------------
// | Source:  ( https://www.fastadmin.net/store/moyi.html )
// +----------------------------------------------------------------------
// | Author: 默毅 <moyi@mymoyi.cn>
// +----------------------------------------------------------------------

namespace addons\moyicosmic\library;

use fast\Http;
use fast\Random;
use think\config\driver\Ini;

class TencentHelper
{
    protected $appkey = "";
    protected $appid = "";
    public function init()
    {
        $conf = get_addon_config('moyicosmic');
        $this->appkey = $conf['aiplat_key'];
        $this->appid = $conf['aiplat_id'];
    }

    /**
     * 单个人脸识别
     * @param $img
     * @param bool $shape
     * @return bool
     */
    public function faceDetectface($img,$shape = false)
    {
        if(substr($img, 0, 4) == 'http'){
            $data = file_get_contents($img);
            $img = base64_encode($data);
        }
        $params = [
            'app_id' => $this->appid,
            'image' => $img,
            'mode' => 0,
            'time_stamp' => time(),
            'nonce_str' => Random::alnum(),
            'sign' => '',
        ];
        $params['sign'] = $this->getReqSign($params, $this->appkey);
        $url = 'https://api.ai.qq.com/fcgi-bin/face/face_detectface';
        $response = Http::post($url,$params);
        $response = json_decode($response, true);
        if ($response["ret"] === 0) {
            if (!$shape){
                $response["data"]['face_list'][0]['face_shape'] = null;
            }
            return $response["data"]['face_list'][0];
        }
        return false;
    }

    /**
     *
     * 人脸搜索
     * @param $img
     * @param int $topn
     * @param string $group_id
     * @return bool
     */
    public function faceFaceidentify($img,$topn=5,$group_id = 'all'){
        if(substr($img, 0, 4) == 'http'){
            $data = file_get_contents($img);
            $img = base64_encode($data);
        }
        $params = [
            'app_id' => $this->appid,
            'image' => $img,
            'time_stamp' => time(),
            'topn'=>$topn,
            'nonce_str' => Random::alnum(),
            'group_id'   => $group_id,
            'sign' => '',
        ];
        $params['sign'] = $this->getReqSign($params, $this->appkey);
        $url = 'https://api.ai.qq.com/fcgi-bin/face/face_faceidentify';
        $response = Http::post($url,$params);
        $response = json_decode($response, true);
        if ($response["ret"] === 0) {
            return $response["data"];
        }
        return false;
    }
    /**
     * 图片标签
     * @param $img
     * @param int $topn
     * @param string $group_id
     * @return bool
     */
    public function imageTag($img){
        if(substr($img, 0, 4) == 'http'){
            $data = file_get_contents($img);
            $img = base64_encode($data);
        }
        $params = [
            'app_id' => $this->appid,
            'image' => $img,
            'time_stamp' => time(),
            'nonce_str' => Random::alnum(),
            'sign' => '',
        ];
        $params['sign'] = $this->getReqSign($params, $this->appkey);
        $url = 'https://api.ai.qq.com/fcgi-bin/image/image_tag';
        $response = Http::post($url,$params);
        $response = json_decode($response, true);
        if ($response["ret"] === 0) {
            return $response["data"]['tag_list'];
        }
        return false;
    }

//


    /**
     *
     * 人脸搜索增加个体
     * @param $img
     * @param string $group_ids
     * @param int $person_id
     * @param string $person_name
     * @param string $tag
     * @return bool
     */
    public function faceNewperson($img,$person_id='test',$person_name = '还珠格格',$group_ids = 'all\\',$tag=''){
        $this->init();
        if(substr($img, 0, 4) == 'http'){
            $data = file_get_contents($img);
            $img = base64_encode($data);
        }
        $params = [
            'app_id' => $this->appid,
            'image' => $img,
            'time_stamp' => time(),
            'nonce_str' => Random::alnum(),
            'group_ids'=>$group_ids,
            'person_id'=>$person_id,
            'person_name'   => $person_name,
            'tag'=>$tag,
            'sign' => '',
        ];
        $params['sign'] = $this->getReqSign($params, $this->appkey);
        $url = 'https://api.ai.qq.com/fcgi-bin/face/face_newperson';
        $response = Http::post($url,$params);
        return $response;
        $response = json_decode($response, true);
        if ($response["ret"] === 0) {
            return $response["data"];
        }
        return false;
    }


//https://api.ai.qq.com/fcgi-bin/face/face_newperson
    /**
     * Describe:鉴权签名
     * @Author: Bygones
     * Date: 2019-06-15
     * Time: 22:33
     * @param array $params
     * @param string $appkey
     * @return string
     */
    public function getReqSign($params, $appkey)
    {
        ksort($params);
        $str = '';
        foreach ($params as $key => $value) {
            if ($value !== '') {
                $str .= $key . '=' . urlencode($value) . '&';
            }
        }
        $str .= 'app_key=' . $appkey;
        $sign = strtoupper(md5($str));
        return $sign;
    }

    /**
     * Describe:Post请求API
     * @Author: Bygones
     * Date: 2019-06-15
     * Time: 22:34
     * @param string $url
     * @param array $params
     * @return bool|string
     */
    public function doHttpPost($url, $params)
    {
        $curl = curl_init();

        $response = false;
        do {
            curl_setopt($curl, CURLOPT_URL, $url);
            $head = [
                'Content-Type: application/x-www-form-urlencoded'
            ];
            curl_setopt($curl, CURLOPT_HTTPHEADER, $head);
            $body = http_build_query($params);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $body);
            curl_setopt($curl, CURLOPT_HEADER, false);
            curl_setopt($curl, CURLOPT_NOBODY, false);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($curl);
            if ($response === false) {
                $response = false;
                break;
            }
            $code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            if ($code != 200) {
                $response = false;
                break;
            }
        } while (0);
        curl_close($curl);
        return $response;
    }

}
