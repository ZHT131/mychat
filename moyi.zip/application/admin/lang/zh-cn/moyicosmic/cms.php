<?php

return [
    'Title'      => '标题',
    'Content'    => '内容',
    'Views'      => '点击量',
    'Createtime' => '添加时间',
    'Updatetime' => '更新时间'
];
