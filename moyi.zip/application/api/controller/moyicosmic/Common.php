<?php

namespace app\api\controller\moyicosmic;


use addons\alioss\controller\Index as alioss;
use addons\qiniu\controller\Index as qiniu;
use app\api\controller\Common as apiCommon;
use app\api\controller\moyicosmic\Base;
use think\Hook;


/**
 * 公共接口
 */
class Common extends Base
{
    // 因为跨域问题 写这里吧 其他云存储按照以下加上就行
    public function upload(){
        switch (empty(Hook::get('upload_config_init'))?'local':Hook::get('upload_config_init')[0]){
            case '\addons\alioss\Alioss':
                $upFun = new alioss();
                break;
            case '\addons\qiniu\Qiniu':
                $upFun = new qiniu;
                break;
            default:
                $upFun = new apiCommon();
                break;
        }
        $upFun->upload();
    }
}
