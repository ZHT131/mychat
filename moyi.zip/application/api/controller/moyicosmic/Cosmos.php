<?php
// +----------------------------------------------------------------------
// | FileName: Cosmos.php
// +----------------------------------------------------------------------
// | Date: 2020-03-16 
// +----------------------------------------------------------------------
// | Source:  ( https://www.fastadmin.net/store/moyi.html )
// +----------------------------------------------------------------------
// | Author: 默毅 <moyi@mymoyi.cn>
// +----------------------------------------------------------------------


namespace app\api\controller\moyicosmic;

use app\admin\model\moyicosmic\Append;
use addons\moyicosmic\library\Common;
use app\admin\model\moyicosmic\Cosmos as CosmosModel;
use app\admin\model\moyicosmic\Like;
use app\admin\model\moyicosmic\Review;
use app\common\controller\Api;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\Exception;
use app\api\controller\moyicosmic\Base;
use think\exception\DbException;

class Cosmos extends Base
{
    /**
     * 获取内容列表
     * @ApiMethod (POST)
     * @param string $id 起始ID
     * @param string $limit 长度
     * @param string $mode 模式
     * @param string $category 类别
     * @throws Exception
     */
    public function getList()
    {
        $mode = $this->request->post('mode', 'new');
        $id = $this->request->post('id', 999999);
        $limit = 10;
        $user_id = $this->auth->getUserinfo()['id'];
        $model = new CosmosModel();
        switch ($mode) {
            case 'hot':
                $list = $model
                    ->with(['user', 'appends', 'like'])
                    ->where('status', 'normal')
                    ->where('user_id', '1')
                    ->where('id', '<', $id)
                    ->limit($limit)
                    ->order('id', 'desc')
                    ->select();
                if ($list) {
                    $model->where('status', 'normal')
                        ->where('id', '<', $id)
                        ->where('id', '>', end($list)->id)
                        ->setInc('views', 1);
                }
                break;
            default:
                $list = $model
                    ->with(['user', 'appends', 'like'])
                    ->where('status', 'normal')
                    ->where('id', '<', $id)
                    ->limit($limit)
                    ->order('id', 'desc')
                    ->select();
                if ($list) {
                    $model->where('status', 'normal')
                        ->where('id', '<', $id)
                        ->where('id', '>', end($list)->id)
                        ->setInc('views', 1);
                }
                break;
        }
        /*
         * 暂未想出快速筛选关联like的方法
         * 如有更有效率的筛选方案 🙇
         * 恳请告之  QQ：445204343
         */
        $like = new Like();
        foreach ($list as $item) {
            $item['isLike'] = $like->where(['pid' => $item->id, 'user_id' => $user_id])->count();
        }
        $this->success('', $list);
    }

    public function getCosmos(){
        $id = $this->request->post('id', 26);
        $model = new CosmosModel();
        $user_id = $this->auth->getUserinfo()['id'];
        $cosmos = $model
            ->with(['user', 'appends', 'like'])
            ->where('status', 'normal')
            ->where('id', $id)
            ->find();
        if ($cosmos) {
            $like = new Like();
            @$cosmos['isLike'] = $like->where(['pid' => $cosmos->id, 'user_id' => $user_id])->count();
            $this->success('',$cosmos);
        }else{
            $this->error('查询错误');
        }
    }

    public function getUserList()
    {
        $mode = $this->request->post('mode', 'new');
        $id = $this->request->post('id', 999999);
        $user = $this->request->post('user', 1);
        $limit = 10;
        $user_id = $this->auth->getUserinfo()['id'];
        $model = new CosmosModel();
        switch ($mode) {
            default:
                $list = $model
                    ->with(['user', 'appends', 'like'])
                    ->where('status', 'normal')
                    ->where('user_id', $user)
                    ->where('id', '<', $id)
                    ->limit($limit)
                    ->order('id', 'desc')
                    ->select();
                if ($list) {
                    $model->where('status', 'normal')
                        ->where('user_id', $user)
                        ->where('id', '<', $id)
                        ->where('id', '>', end($list)->id)
                        ->setInc('views', 1);
                }

                break;
        }
        $like = new Like();
        foreach ($list as $item) {
            $item['isLike'] = $like->where(['pid' => $item->id, 'user_id' => $user_id])->count();
        }
        $this->success('', $list);

    }


    /**
     * 获取评论列表
     * @ApiMethod (POST)
     *
     * @param string $id fid
     * @param string $endId 结束ID
     * @param string $limit 长度
     * @param string $mode 模式
     * @param string $category 类别
     * @throws Exception
     */
    public function getReview()
    {
        $mode = $this->request->post('mode', 'new');
        $id = $this->request->post('id', 342);
        $endId = $this->request->post('endId', 999999);
        $limit = 50;
        $model = new Review();
        switch ($mode) {
            default:
                $list = $model
                    ->with(['user', 'appends', 'reply'])
                    ->where(['pid' => $id])
                    ->where('status', 'normal')
                    ->where('id', '<', $endId)
                    ->limit($limit)
                    ->order('id', 'desc')
                    ->select();
                break;
        }
        $this->success('', $list);
    }

    /**
     * 评论
     * @ApiMethod (POST)
     *
     * @param string $id pid
     * @param string text 模式
     * @param string $category 类别
     * @throws Exception
     */
    public function review()
    {
        $pid = $this->request->post('pid', 0);
        $reply_id = $this->request->post('reply_id', 0);
        $reply_user_id = $this->request->post('reply_user_id', 0);
        $text = $this->request->post('text', '');
        $limit = 50;
        $audit = Common::auditText($text);
        $model = new Review();
        $model::create([
            'pid' => $pid,
            'status' => $audit ? 'normal' : 'hidden',
            'user_id' => $this->auth->getUserinfo()['id'],
            'reply_id' => $reply_id,
            'reply_user_id' => $reply_user_id,
            'text' => $text
        ]);
        $list = $model
            ->with(['user', 'appends', 'reply'])
            ->where(['pid' => $pid])
            ->where('status', 'normal')
            ->limit($limit)
            ->order('id', 'desc')
            ->select();
        CosmosModel::get($pid)->setInc('reviews');
        $this->success($audit ? '' : '您发布的文本内容涉嫌违规(色情、广告、灌水、渉政、辱骂等内容风险！)', $list);
    }


    /**
     * 标记
     * @ApiMethod (POST)
     *
     * @param string $pid pid
     * @throws Exception
     */
    public function like()
    {
        $pid = $this->request->post('pid', 324);
        $user_id = $this->auth->getUserinfo()['id'];

        if (Like::get(['pid' => $pid, 'user_id' => $user_id])) {
            CosmosModel::get($pid)->setDec('likes');
            Like::get(['pid' => $pid, 'user_id' => $user_id])->delete();
            $this->success('', 0);
        } else {
            CosmosModel::get($pid)->setInc('likes');
            Like::create(['pid' => $pid, 'user_id' => $this->auth->getUserinfo()['id']]);
            $this->success('', 1);
        }
    }

    /**
     * 标记
     * @ApiMethod (POST)
     *
     * @param string $pid pid
     * @throws Exception
     */
    public function push()
    {

        $text = $this->request->post('text');
        $images = $this->request->post('images');
        $secret = $this->request->post('secret', 'all');
        $flag = $this->request->post('flag');
        $user_id = $this->auth->getUserinfo()['id'];
        if (!Common::auditText($text)) {
            $this->error('您发布的文本内容涉嫌违规(色情、广告、灌水、渉政、辱骂等内容风险！)');
        }
        if (!Common::auditImages($images)) {
            $this->error('您发布的图片内容涉嫌违规(色情、广告、灌水、渉政、辱骂等内容风险！)');
        }
        $arr = [
            'text' => $text,
            'images' => $images,
            'secret' => $secret,
            'flag' => $flag,
            'user_id' => $user_id,
            'status' => 'normal'
        ];
        if (CosmosModel::create($arr)) {
            $this->success('推送成功');
        } else {
            $this->error('不可抗拒力导致推送失败');
        }
    }

    public function test()
    {
        try {

            $user_id = $this->auth->getUserinfo()['id'];
            $user = CosmosModel::hasWhere('like', ['user_id' => $user_id])->field();
            $this->success($user);
            $mode = $this->request->post('mode', 'new');
            $id = $this->request->post('id', 999999);
            $limit = 10;
            $list = CosmosModel::get(['id' => 342])->select();

            $this->success('', $list);


            $model = new CosmosModel();
            switch ($mode) {
                default:
                    $list = $model
                        ->with(['user', 'appends'])
                        ->hasWhere('like', ['user_id' => $user_id])
                        ->where('status', 'normal')
                        ->where('id', '<', $id)
                        ->limit($limit)
                        ->order('id', 'desc')
                        ->select();

                    $model->where('status', 'normal')
                        ->where('id', '<', $id)
                        ->where('id', '>', end($list)->id)
                        ->setInc('views', 1);
                    break;
            }
            $this->success('', $list);

        } catch (DataNotFoundException $e) {
        } catch (ModelNotFoundException $e) {
        } catch (DbException $e) {
        } catch (Exception $e) {
            $this->error('查询出错');
        }

    }
}