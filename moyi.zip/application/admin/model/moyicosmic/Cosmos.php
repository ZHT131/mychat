<?php

namespace app\admin\model\moyicosmic;

use think\Model;
use traits\model\SoftDelete;

class Cosmos extends Model
{

    use SoftDelete;


    // 追加属性
    protected $append = [
        'images_arr'
    ];
    // 表名
    protected $name = 'moyicosmic_cosmos';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = 'deletetime';

    public function user()
    {
        return $this->hasOne('User','id', 'user_id')->bind(['nickname','avatar','bio']);
    }

    public function appends()
    {
        return $this->hasOne('Append','user_id', 'user_id')->bind(['frame']);
    }


    public function comments(){
        return $this->hasMany('Like','pid');

    }

    public function like()
    {
        return $this->hasMany('Like','pid', 'id');
   }

    public function getStatusList()
    {
        return ['normal' => __('Normal'), 'hidden' => __('Hidden')];
    }

    /*
     * 图片组分拆数组
     */
    public function getImagesArrAttr($value, $data)
    {
        $value = $value ? $value : $data['images'];
        $valueArr = explode(',', $value);
        return $valueArr;
    }
}
