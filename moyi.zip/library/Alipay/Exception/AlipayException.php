<?php

namespace addons\moyicosmic\library\Alipay\Exception;

/**
 * 本 SDK 内所有异常均继承自此类
 */
abstract class AlipayException extends \Exception
{
}
